# Musculoskeletal MSC-based therapy: a registry-wide evidence atlas integrated with donor-cell and joint-niche transcriptomics

Reproducibility package for the study *"Mesenchymal stromal cell therapy for musculoskeletal
disorders: a registry-wide evidence atlas integrated with donor-cell and joint-niche
transcriptomics"* (version 1.0.0).

The study confronts the design of all 412 registered musculoskeletal MSC-based interventional
trials (ClinicalTrials.gov, 2000-2026) with public transcriptomes of the therapeutic cell and
the target joint: donor-state bone-marrow MSCs (GSE267908), adipose MSC secretome on inflamed
chondrocytes (GSE239343), a pain-stratified single-cell atlas of late-stage osteoarthritic
synovium (GSE248453) and its replication cohort (GSE216651).

## Repository layout

```
code/                    analysis and figure scripts (see Reproduction below)
results/                 every intermediate result table and JSON log used in the manuscript
data/                    source-file checksums, probe annotations, ClinicalTrials.gov record
                         archive (642-record candidate pool + 412 analytic-trial records),
                         GEO series matrices, reference list
supplementary_tables/    Tables S1-S10 exported from the result tables
SHA256SUMS.txt           checksum of every file in this package
```

## Data sources (all public)

- ClinicalTrials.gov API v2 (https://clinicaltrials.gov/api/v2), queried 21 September 2026 with
  nine condition-scoped searches; 642 candidate records screened, 412 musculoskeletal MSC-based
  trials analysed. Full record archive: `data/ctgov_raw2/` (candidates) and `data/ctgov_full/`
  (analytic trials), manifest in `data/ctgov_manifest.json`.
- Gene Expression Omnibus: GSE267908, GSE239343, GSE248453, GSE216651, downloaded 21-22
  September 2026. Series matrices in `data/geo_sm/`; single-cell RAW archives
  (`GSE248453_RAW.tar`, `GSE216651_RAW.tar`) were downloaded from GEO and are checksummed in
  `data/source_data_checksums.csv`.
- Probe annotations: Bioconductor `hgu133plus2.db` and the GEO GPL10558 annotation table
  (`data/GPL570_probe2symbol.tsv`, `data/GPL10558_probe2symbol.tsv`).

SHA-256 checksums of every source file used are listed in `data/source_data_checksums.csv`; the
raw files themselves remain at their public sources (GEO, ClinicalTrials.gov).

Images are not distributed in this package; the analysis scripts in `code/` regenerate every
result figure and table directly from the archived inputs. The processed single-cell objects
are likewise regenerable with `scrna_pipeline.py` and `replica_pipeline.py`.

## Requirements

Python 3.12 with: pandas, numpy, scipy, statsmodels, scikit-learn, scanpy 1.12 (with
anndata, leidenalg, igraph), matplotlib, lxml. Registry scripts call the ClinicalTrials.gov
API v2; all other analyses run offline on the archived files.

## Reproduction

```
python code/registry_analysis.py      # ClinicalTrials.gov queries -> candidate + trial tables
python code/classify_registry2.py     # condition/product/outcome/dose classification
python code/bulk_analysis.py          # GSE267908 + GSE239343 differential and module analyses
python code/scrna_pipeline.py         # GSE248453 QC, clustering, annotation, DA, LR, robustness
python code/replica_pipeline.py       # GSE216651 replication analyses
python code/figs_registry_a.py        # Figure 2, Figure 3
python code/figs_registry_b.py        # Figure 4, Figure 5
python code/fig_bulk.py               # Figure 8
python code/figs_scrna.py             # Figure 6, Figure 7
python code/fig_workflow.py           # Figure 1 (graphical workflow)
python code/fig_integration.py        # Figure 9 (premise-evidence integration)
```

Scripts resolve all paths relative to the repository root (`BASE`); place the GEO downloads
under `data/geo/` if rerunning from the raw archives.

## License

Code: MIT (see `LICENSE`). Data, tables and figures: CC-BY-4.0.

## Citation

See `CITATION.cff`.
