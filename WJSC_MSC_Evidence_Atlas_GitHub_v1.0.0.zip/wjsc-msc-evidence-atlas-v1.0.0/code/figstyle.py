# -*- coding: utf-8 -*-
"""Shared figure style: sans-serif, >=12pt text, 920 DPI composites, no bar charts."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams['font.family'] = 'sans-serif'
rcParams['font.sans-serif'] = ['Helvetica', 'Arial', 'DejaVu Sans']
rcParams['font.size'] = 13
rcParams['axes.titlesize'] = 13
rcParams['axes.labelsize'] = 13
rcParams['xtick.labelsize'] = 12
rcParams['ytick.labelsize'] = 12
rcParams['legend.fontsize'] = 11
rcParams['axes.linewidth'] = 1.0
rcParams['xtick.major.width'] = 1.0
rcParams['ytick.major.width'] = 1.0
rcParams['savefig.dpi'] = 920
rcParams['savefig.bbox'] = 'tight'
rcParams['savefig.facecolor'] = 'white'
rcParams['axes.unicode_minus'] = False
rcParams['pdf.fonttype'] = 42
rcParams['ps.fonttype'] = 42

PALETTE = {
    'main': '#2166ac', 'alt': '#b2182b', 'third': '#1b7837',
    'light': '#92c5de', 'warm': '#f4a582', 'grey': '#8a8a8a',
    'knee': '#2166ac', 'hip': '#67a9cf', 'otherOA': '#c6dbef',
    'cart': '#1b7837', 'bone': '#a6dba0', 'tendon': '#e08214',
    'spine': '#fdb863', 'onec': '#762a83', 'op': '#c51b7b',
    'oi': '#e7298a', 'msk_other': '#bdbdbd',
    'bm': '#2166ac', 'ad': '#b2182b', 'uc': '#1b7837', 'syn': '#762a83', 'unspec': '#9e9e9e',
    'OA': '#b2182b', 'healthy': '#2166ac',
}
FAMILY_ORDER = ['knee osteoarthritis', 'hip osteoarthritis', 'other osteoarthritis',
                'cartilage defect/injury', 'fracture/bone defect', 'tendon/ligament/meniscus',
                'spine degeneration/fusion', 'osteonecrosis', 'osteoporosis',
                'osteogenesis imperfecta', 'other musculoskeletal']
FAMILY_COLORS = [PALETTE['knee'], PALETTE['hip'], PALETTE['otherOA'], PALETTE['cart'],
                 PALETTE['bone'], PALETTE['tendon'], PALETTE['spine'], PALETTE['onec'],
                 PALETTE['op'], PALETTE['oi'], PALETTE['msk_other']]
FAMILY_SHORT = {'knee osteoarthritis': 'Knee OA', 'hip osteoarthritis': 'Hip OA',
                'other osteoarthritis': 'Other OA', 'cartilage defect/injury': 'Cartilage defect',
                'fracture/bone defect': 'Fracture/bone defect', 'tendon/ligament/meniscus': 'Tendon/ligament/meniscus',
                'spine degeneration/fusion': 'Spine', 'osteonecrosis': 'Osteonecrosis',
                'osteoporosis': 'Osteoporosis', 'osteogenesis imperfecta': 'OI',
                'other musculoskeletal': 'Other MSK'}


def despine(ax, sides=('top', 'right')):
    for s in sides:
        ax.spines[s].set_visible(False)


def panel_label(ax, letter, dx=-0.08, dy=1.04):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=16,
            fontweight='bold', va='bottom', ha='right')
