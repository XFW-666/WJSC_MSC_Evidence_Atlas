# -*- coding: utf-8 -*-
"""Fig 4 (scale & outcomes) and Fig 5 (dose & attrition). No bar charts; 600 DPI."""
import io, os, json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from scipy import stats
from figstyle import (plt, PALETTE, FAMILY_ORDER, FAMILY_COLORS, FAMILY_SHORT,
                      despine, panel_label)

BASE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.join(BASE, 'results', 'registry')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)

df = pd.read_csv(os.path.join(REG, 'trials_ortho_clean.csv'), dtype=str)
df['phase'] = df['phase'].replace({'NA': 'not applicable'})
df['enrollment_num'] = pd.to_numeric(df['enrollment'], errors='coerce')
A = json.loads(io.open(os.path.join(REG, 'registry_analysis.json'), encoding='utf-8').read())

fams = [f for f in FAMILY_ORDER if f in set(df['family'])]
short = [FAMILY_SHORT[f] for f in fams]

def status_map(s):
    if s in ('RECRUITING', 'ACTIVE_NOT_RECRUITING', 'ENROLLING_BY_INVITATION', 'NOT_YET_RECRUITING', 'AVAILABLE'):
        return 'active'
    if s == 'COMPLETED':
        return 'completed'
    if s in ('TERMINATED', 'WITHDRAWN', 'SUSPENDED', 'NO_LONGER_AVAILABLE'):
        return 'discontinued'
    return 'unknown'

df['status_grp'] = df['status'].map(status_map)

# ============ FIG 4 (2x3 with predictors forest + posted-outcomes SMD forest) ============
fig = plt.figure(figsize=(12.5, 9.6))
gs = fig.add_gridspec(3, 2, hspace=0.541, wspace=0.55, width_ratios=[1.12, 0.88],
                      left=0.11, right=0.965, top=0.94, bottom=0.08)

# (A) enrollment ridge by family (KDE, horizontal)
ax = fig.add_subplot(gs[0, 0])
en = df.dropna(subset=['enrollment_num']).copy()
en['enrollment_num'] = en['enrollment_num'].astype(float)
en['log_enr'] = np.log10(en['enrollment_num'].clip(lower=1))
xs = np.linspace(0, 3, 220)
ymax = 0
for i, f in enumerate(fams):
    vals = en.loc[en['family'] == f, 'log_enr'].values
    if len(vals) < 4:
        continue
    kde = stats.gaussian_kde(vals)
    yv = kde(xs)
    yv = yv / yv.max()
    ax.fill_between(xs, i + yv * 0.82, i, color=FAMILY_COLORS[FAMILY_ORDER.index(f)],
                    alpha=0.55, lw=0)
    ax.plot(xs, i + yv * 0.82, color=FAMILY_COLORS[FAMILY_ORDER.index(f)], lw=1.1)
    med = np.median(vals)
    ax.plot([med], [i + 0.41], 'o', color='white', ms=4, markeredgecolor='#222222',
            markeredgewidth=0.8, zorder=5)
    ymax = max(ymax, i)
ax.set_yticks(range(len(fams)))
ax.set_yticklabels(short, fontsize=8.5)
ax.set_xlim(0, 3)
ax.set_xticks([0, 1, 2, 3])
ax.set_xticklabels(['1', '10', '100', '1000'])
ax.set_xlabel('Planned enrollment (participants, log scale)')
ax.set_ylim(-0.4, len(fams) + 0.9)
despine(ax)
ax.set_title('Enrollment distributions (median = white dot)', loc='left', fontsize=10.5)
panel_label(ax, 'A', dx=-0.16, dy=1.06)

# (B) trial duration KDE + results posting lag KDE
ax = fig.add_subplot(gs[0, 1])
dur = []
for _, r in df.iterrows():
    try:
        s = pd.Timestamp(r['start'])
        e = pd.Timestamp(r['primary_completion'])
        if pd.notna(s) and pd.notna(e) and e > s:
            dur.append((e - s).days / 365.25)
    except Exception:
        pass
res = pd.read_csv(os.path.join(REG, 'fig_results_lag.csv'))
x1 = np.linspace(0, 8, 260)
k1 = stats.gaussian_kde(np.clip(dur, 0, 8))
ax.fill_between(x1, k1(x1), color=PALETTE['main'], alpha=0.3, lw=0)
ax.plot(x1, k1(x1), color=PALETTE['main'], lw=1.6,
        label='Start → primary completion\n(median %.1f y, n=%d)' % (np.median(dur), len(dur)))
lag = res['post_lag_y'].dropna()
if len(lag) >= 4:
    x2 = np.linspace(0, 8, 260)
    k2 = stats.gaussian_kde(np.clip(lag, 0, 8))
    ax.fill_between(x2, k2(x2), color=PALETTE['alt'], alpha=0.3, lw=0)
    ax.plot(x2, k2(x2), color=PALETTE['alt'], lw=1.6,
            label='Primary completion → results posted\n(median %.1f y, n=%d)' % (lag.median(), len(lag)))
ax.set_xlabel('Years')
ax.set_ylabel('Density')
ax.set_xlim(0, 8)
ax.legend(fontsize=8.2, frameon=False, loc='upper right')
despine(ax)
ax.set_title('Trial timelines', loc='left', fontsize=10.5)
panel_label(ax, 'B', dx=-0.14, dy=1.06)

# (C) primary outcome domain share heatmap (family x domain)
ax = fig.add_subplot(gs[1, 0])
doms = ['function', 'safety', 'pain', 'imaging/structure', 'quality of life', 'biomarker/biology']
dom_labels = ['Function', 'Safety', 'Pain', 'Imaging/\nstructure', 'Quality\nof life', 'Biomarker']
mat = np.zeros((len(fams), len(doms)))
for i, f in enumerate(fams):
    sub = df[df['family'] == f]
    for j, d in enumerate(doms):
        mat[i, j] = 100.0 * sub['primary_domains'].fillna('').str.contains(d, regex=False).mean()
im = ax.imshow(mat, cmap=LinearSegmentedColormap.from_list('rdb', ['#ffffff', PALETTE['main']]),
               aspect='auto', vmin=0, vmax=100)
for i in range(len(fams)):
    for j in range(len(doms)):
        v = mat[i, j]
        ax.text(j, i, '%.0f' % v, ha='center', va='center', fontsize=7.6,
                color='white' if v > 60 else '#333333')
ax.set_xticks(range(len(doms))); ax.set_xticklabels(dom_labels, fontsize=8.5)
SHORTEN = {'Tendon/ligament/meniscus': 'Tendon/lig.', 'Fracture/bone defect': 'Fracture/bone', 'Cartilage defect/injury': 'Cartilage'}
ax.set_yticks(range(len(fams))); ax.set_yticklabels([SHORTEN.get(s, s) for s in short], fontsize=8.5)
cbar = plt.colorbar(im, ax=ax, fraction=0.045, pad=0.03)
cbar.set_label('% of family trials', fontsize=8.5)
ax.set_title('Primary outcome domains (% of family trials)', loc='left', fontsize=10.5)
panel_label(ax, 'C', dx=-0.16, dy=1.06)

# (D) results reporting: share with posted results (dot + Wilson CI) per family
ax = fig.add_subplot(gs[1, 1])
from statsmodels.stats.proportion import proportion_confint
ys, xs_, err_lo, err_hi, ns = [], [], [], [], []
for i, f in enumerate(fams):
    sub = df[df['family'] == f]
    n = len(sub)
    k = int((sub['has_results'] == 'True').sum())
    if n < 10:
        continue
    lo, hi = proportion_confint(k, n, method='wilson')
    ys.append(FAMILY_SHORT[f]); xs_.append(100 * k / n); err_lo.append(100 * (k / n - lo)); err_hi.append(100 * (hi - k / n)); ns.append(n)
y = np.arange(len(ys))[::-1]
ax.errorbar(xs_, y, xerr=[err_lo, err_hi], fmt='o', color=PALETTE['main'],
            ecolor=PALETTE['main'], elinewidth=1.4, capsize=3, ms=6)
for xx, yy, lab in zip(xs_, y, ['%d/%d' % (int((df[df['family'] == f]['has_results'] == 'True').sum()),
                                               len(df[df['family'] == f]))
                                for f in fams if len(df[df['family'] == f]) >= 10]):
    ax.text(xx + 11, yy, lab, va='center', fontsize=8, color='#333333')
ax.axvline(100 * A['n_results'] / A['n_trials'], color=PALETTE['alt'], lw=1.2, ls='--')
ax.text(100 * A['n_results'] / A['n_trials'] + 0.8, 0.15, 'overall %.1f%%' % (100 * A['share_results']),
        fontsize=8.4, color=PALETTE['alt'], va='bottom')
ax.set_yticks(y); ax.set_yticklabels([SHORTEN.get(s, s) for s in ys], fontsize=8.5)
ax.set_xlabel('Trials with registry-posted results (%)')
ax.set_xlim(0, 45)
despine(ax)
ax.set_title('Results reporting on ClinicalTrials.gov', loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=-0.16, dy=1.06)

# (E) multivariable logistic predictors (one row per feature, two models)
ax = fig.add_subplot(gs[2, 0])
pred = pd.read_csv(os.path.join(REG, 'predictors.csv'))
main = pred[pred['outcome'].isin(['completion', 'results posting'])]
feat_lab = {
    'yr_centered': 'Start year (per +5 y)', 'log_enroll': 'Enrolment (per x10)',
    'phase3plus': 'Phase 3/4 (vs 1/2)', 'industry': 'Industry sponsor',
    'autologous': 'Autologous', 'allogeneic': 'Allogeneic',
    'src_bm': 'Bone-marrow source', 'src_ad': 'Adipose source', 'src_uc': 'Umbilical-cord source',
    'knee_oa': 'Knee OA (vs other)', 'region_asia': 'Region: Asia', 'region_west': 'Region: West',
    'phase_na': 'No phase designation'}
keep_f = []
for f in feat_lab:
    sub = main[main['feature'] == f]
    if len(sub) and ((sub['ci_hi'] < 1).any() or (sub['ci_lo'] > 1).any()
                     or f in ('yr_centered', 'log_enroll', 'allogeneic', 'knee_oa')):
        keep_f.append(f)
y = np.arange(len(keep_f))[::-1]
for yi, f in zip(y, keep_f):
    for outcome, colr, off in [('completion', PALETTE['main'], -0.11),
                               ('results posting', PALETTE['alt'], 0.11)]:
        sub = main[(main['feature'] == f) & (main['outcome'] == outcome)]
        if not len(sub):
            continue
        r = sub.iloc[0]
        lo = min(max(r['ci_lo'], 0.02), 60)
        hi = min(max(r['ci_hi'], 0.02), 60)
        ax.plot([lo, hi], [yi + off, yi + off], color=colr, lw=2.0, alpha=0.9)
        ax.plot([r['OR']], [yi + off], 'o', color=colr, ms=7,
                markeredgecolor='white', markeredgewidth=0.8)
ax.axvline(1, color='#888888', lw=1, ls='--')
ax.set_xscale('log')
ax.set_yticks(y)
ax.set_yticklabels([feat_lab[f] for f in keep_f], fontsize=9.5)
ax.set_xlabel('Adjusted odds ratio (logistic, 95% CI)', fontsize=10)
ax.set_xlim(0.05, 40)
from matplotlib.lines import Line2D as LN2E, Line2D as LN2
handles = [LN2E([0], [0], marker='o', color=PALETTE['main'], lw=1.6, markersize=6),
           LN2E([0], [0], marker='o', color=PALETTE['alt'], lw=1.6, markersize=6)]
ax.legend(handles, ['completion', 'results posting'], fontsize=8.4, frameon=False,
          loc='lower right')
despine(ax)
ax.set_title('What predicts completion and reporting?', loc='left', fontsize=10.5)
panel_label(ax, 'E', dx=-0.14, dy=1.06)

# (F) posted-results effect sizes (Hedges g) forest
ax = fig.add_subplot(gs[2, 1])
smd = pd.read_csv(os.path.join(REG, 'posted_smd.csv'))
smd = smd.dropna(subset=['hedges_g']).sort_values('hedges_g')
y = np.arange(len(smd))[::-1]
favc = {'MSC arm better': PALETTE['third'], 'comparator better': PALETTE['alt'], 'ambiguous': '#999999'}
for yi, (_, r) in zip(y, smd.iterrows()):
    lo, hi = r['hedges_g'] - 1.96 * r['se'], r['hedges_g'] + 1.96 * r['se']
    ax.plot([lo, hi], [yi, yi], color=favc.get(r['favour'], '#999999'), lw=1.4, alpha=0.85)
    ax.plot([r['hedges_g']], [yi], 'o', color=favc.get(r['favour'], '#999999'), ms=5)
ax.axvline(0, color='#555555', lw=1)
ax.set_yticks(y)
ax.set_yticklabels(smd['measure'].str.slice(0, 38), fontsize=6.8)
ax.set_xlabel("Hedges g (MSC arm vs comparator, registry-posted means ± SD)")
ax.set_xlim(-3, 9)
handles = [LN2([0], [0], marker='o', color=favc[k], lw=1.4, markersize=5) for k in favc]
ax.legend(handles, list(favc.keys()), fontsize=7.4, frameon=False, loc='lower right')
despine(ax)
ax.set_title('The 11 trials that posted results: mixed effects', loc='left', fontsize=10.5)
panel_label(ax, 'F', dx=-0.2, dy=1.06)

fig.savefig(os.path.join(FIG, 'Fig4_scale_outcomes.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig4_scale_outcomes.pdf'), dpi=920)
plt.close(fig)
print('Fig4 saved (2x3)')

# ============ FIG 5 ============
fig = plt.figure(figsize=(11, 4.45))
gs = fig.add_gridspec(1, 3, wspace=0.26, width_ratios=[1, 0.85, 1.25], left=0.07, right=0.965, top=0.86, bottom=0.19)

dd = pd.read_csv(os.path.join(REG, 'fig_doses.csv'))

# (A) paired-slope chart: dose disclosure rate vs completion rate per family (Wilson CI)
from statsmodels.stats.proportion import proportion_confint
ax = fig.add_subplot(gs[0])
fams5 = [f for f in fams if len(df[df['family'] == f]) >= 10]
rows5 = []
for f in fams5:
    sub = df[df['family'] == f]
    n = len(sub)
    k_d = int((sub['dose_reported'] == 'True').sum())
    k_c = int((sub['status'] == 'COMPLETED').sum())
    lo_d, hi_d = proportion_confint(k_d, n, method='wilson')
    lo_c, hi_c = proportion_confint(k_c, n, method='wilson')
    rows5.append({'family': f, 'n': n,
                  'dose': 100 * k_d / n, 'dose_lo': 100 * lo_d, 'dose_hi': 100 * hi_d,
                  'comp': 100 * k_c / n, 'comp_lo': 100 * lo_c, 'comp_hi': 100 * hi_c})
r5 = pd.DataFrame(rows5)
xt = {0: 'Numeric dose\ndisclosed', 1: 'Reached\ncompletion'}
for _, r in r5.iterrows():
    colr = FAMILY_COLORS[FAMILY_ORDER.index(r['family'])]
    ax.plot([0, 1], [r['dose'], r['comp']], color=colr, lw=1.8, alpha=0.85)
    ax.errorbar([0], [r['dose']], yerr=[[r['dose'] - r['dose_lo']], [r['dose_hi'] - r['dose']]],
                fmt='o', color=colr, ms=5.5, capsize=2.5, lw=1.2)
    ax.errorbar([1], [r['comp']], yerr=[[r['comp'] - r['comp_lo']], [r['comp_hi'] - r['comp']]],
                fmt='o', color=colr, ms=5.5, capsize=2.5, lw=1.2)

import matplotlib.lines as mlines
handles_s = [mlines.Line2D([], [], marker='o', color='none',
                           markerfacecolor=FAMILY_COLORS[FAMILY_ORDER.index(r['family'])],
                           markersize=6, label='%s (n=%d)' % (FAMILY_SHORT[r['family']], r['n']))
             for _, r in r5.iterrows()]
ax.legend(handles=handles_s, loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=3,
          fontsize=7.6, frameon=False, handletextpad=0.25, columnspacing=1.0)
ax.set_xticks([0, 1])
ax.set_xticklabels([xt[0], xt[1]], fontsize=9)
ax.set_xlim(-0.22, 1.22)
ax.set_ylabel('% of family trials')
ax.set_ylim(-4, 92)
ax.set_yticks([0, 20, 40, 60, 80, 100])
despine(ax)
ax.set_title('Dose disclosure vs completion, per family\n(dots = rate with Wilson 95% CI)', loc='left', fontsize=10.5)
panel_label(ax, 'A', dx=-0.18, dy=1.12)

# (B) dose values strip on log10 axis
ax = fig.add_subplot(gs[1])
vals = dd['max_dose'].values.astype(float)
rng = np.random.default_rng(7)
yj = rng.uniform(-0.16, 0.16, len(vals))
ax.semilogx(vals, yj, 'o', color=PALETTE['main'], ms=5, alpha=0.75)
med = np.median(vals)
ax.axvline(med, color=PALETTE['alt'], lw=1.4, ls='--')
ax.text(med * 1.12, -0.36, 'median %.1f×10⁶' % (med / 1e6), fontsize=8.4, color=PALETTE['alt'])
ax.axvline(vals.min(), color='#888888', lw=1, ls=':')
ax.axvline(vals.max(), color='#888888', lw=1, ls=':')
ax.text(vals.min() * 0.94, -0.5, '%.1f×10⁶' % (vals.min() / 1e6), fontsize=7.8, ha='right', color='#555555')
ax.text(vals.max() * 1.06, -0.5, '%.0f×10⁶' % (vals.max() / 1e6), fontsize=7.8, color='#555555')
ax.annotate('', xy=(vals.max(), 0.36), xytext=(vals.min(), 0.36),
            arrowprops=dict(arrowstyle='<->', color='#666666', lw=1))
ax.text(np.sqrt(vals.min() * vals.max()), 0.42, '%d-fold span' % round(vals.max() / vals.min()),
        fontsize=8.6, ha='center', color='#333333')
ax.set_ylim(-0.58, 0.55)
ax.set_yticks([])
ax.set_xlabel('Reported cell dose per injection (cells, log scale)')
despine(ax)
ax.set_title('Stated doses (n=%d trials)' % len(dd), loc='left', fontsize=10.5)
panel_label(ax, 'B', dx=-0.14, dy=1.12)

# (C) polar rose: discontinued-trial fate composition
ax = fig.add_subplot(gs[2], projection='polar')
from collections import Counter
disc = df[df['status'].isin(['WITHDRAWN', 'TERMINATED', 'SUSPENDED', 'NO_LONGER_AVAILABLE'])]
cnt = Counter()
for _, r in disc.iterrows():
    wc = r['why_cat'] if isinstance(r['why_cat'], str) and r['why_cat'] else 'no reason given'
    cnt[wc] += 1
order_c = sorted(cnt.items(), key=lambda kv: -kv[1])
labels_c = [k for k, _ in order_c]
vals_c = [v for _, v in order_c]
colmap_c = {'no reason given': '#bdbdbd', 'unspecified/other': '#cccccc',
            'recruitment/enrollment': PALETTE['main'], 'funding/resource': PALETTE['alt'],
            'COVID-19 pandemic': '#762a83', 'operational/administrative': PALETTE['third'],
            'business/strategic': '#e08214', 'safety/medical': '#c51b7b'}
colors_c = [colmap_c.get(k, '#999999') for k in labels_c]
N = len(vals_c)
theta = np.linspace(0, 2 * np.pi, N, endpoint=False)
width = 2 * np.pi / N * 0.82
bars = ax.bar(theta, vals_c, width=width, color=colors_c, edgecolor='white', lw=1.2, alpha=0.92)
ax.set_xticks([])
ax.set_rlabel_position(90 / N)
ax.set_yticks([5, 10, 15])
ax.set_yticklabels(['5', '10', '15'], fontsize=6.6, color='#888888')
ax.tick_params(axis='y', pad=-2)
ax.grid(axis='y', alpha=0.35, lw=0.7)
ax.spines['polar'].set_visible(False)
for th, v in zip(theta, vals_c):
    ax.text(th, v + 0.7, str(int(v)), ha='center', va='center', fontsize=7.8,
            color='#333333', fontweight='bold')
# move category names to right legend to avoid polar-label clipping
import matplotlib.patches as _mp
handles_c = [_mp.Patch(facecolor=colmap_c.get(k, '#999999'),
                       label='%s (%d)' % (k.replace('recruitment/enrollment', 'recruitment')
                                          .replace('funding/resource', 'funding')
                                          .replace('operational/administrative', 'operational')
                                          .replace('no reason given', 'no reason given')
                                          .replace('COVID-19 pandemic', 'COVID-19')
                                          .replace('unspecified/other', 'unspecified'),
                                          v))
             for k, v in order_c]
ax.legend(handles=handles_c, loc='upper right', bbox_to_anchor=(1.06, 0.12), fontsize=8.2,
          frameon=True, framealpha=0.95, edgecolor='#333333', title='fate category', title_fontsize=8.6)
ax.set_title('Fate of the %d discontinued trials\n(25 withdrawn, 14 terminated, 3 suspended)' % len(disc),
             fontsize=10.5, pad=18)
ax.text(-0.16, 1.14, 'C', transform=ax.transAxes, fontsize=13, fontweight='bold',
        va='bottom', ha='right')

fig.savefig(os.path.join(FIG, 'Fig5_dose_attrition.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig5_dose_attrition.pdf'), dpi=920)
plt.close(fig)
print('Fig5 saved')
