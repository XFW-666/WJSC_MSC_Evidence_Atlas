# -*- coding: utf-8 -*-
"""Fig 8: bulk transcriptomics — secretome rescue (GSE239343) + donor-state (GSE267908)."""
import io, os, json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy import stats
from figstyle import (plt, PALETTE, despine, panel_label)
from bulk_analysis import parse_series_matrix, collapse_to_genes, MODULES

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, 'data')
BULK = os.path.join(BASE, 'results', 'bulk')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)

LOGJ = json.loads(io.open(os.path.join(BASE, 'results', 'bulk_analysis_log.json'), encoding='utf-8').read())

deg_infl = pd.read_csv(os.path.join(BULK, 'GSE239343_TNF_vs_Chondrocytes.csv'), index_col=0)
deg_resc = pd.read_csv(os.path.join(BULK, 'GSE239343_ASCCM_vs_TNF.csv'), index_col=0)
ms1 = pd.read_csv(os.path.join(BULK, 'GSE239343_module_scores.csv'), index_col=0)
deg_donor = pd.read_csv(os.path.join(BULK, 'GSE267908_OAvsND_MSC.csv'), index_col=0)
ms2 = pd.read_csv(os.path.join(BULK, 'GSE267908_module_scores.csv'), index_col=0)

grp1 = ['Chondrocytes'] * 3 + ['ASC'] * 3 + ['TNF'] * 3 + ['TNF+ASC-CM'] * 3

# ---- expression matrices for heatmaps
p2s = {}
for ln in io.open(os.path.join(DATA, 'GPL10558_probe2symbol.tsv'), encoding='utf-8').read().splitlines()[1:]:
    a, b = ln.split('\t'); p2s[a] = b
expr1, titles1, gsms1, _ = parse_series_matrix(os.path.join(DATA, 'geo_sm', 'GSE239343_series_matrix.txt'))
ge1 = collapse_to_genes(expr1, p2s)
ge1 = np.log2(ge1 + 1)

p2s2 = {}
for ln in io.open(os.path.join(DATA, 'GPL570_probe2symbol.tsv'), encoding='utf-8').read().splitlines()[1:]:
    a, b = ln.split('\t'); p2s2[a] = b
expr2, titles2, gsms2, _ = parse_series_matrix(os.path.join(DATA, 'geo_sm', 'GSE267908_series_matrix.txt'))
ge2 = collapse_to_genes(expr2, p2s2)
ge2 = np.log2(ge2 + 1)

fig = plt.figure(figsize=(12.5, 11.8))
gs = fig.add_gridspec(5, 3, hspace=0.80, wspace=0.85,
                      height_ratios=[1.6, 1.05, 1.85, 0.8, 1.3],
                      left=0.075, right=0.97, top=0.955, bottom=0.045)

# (A) volcano TNF vs chondrocytes
ax = fig.add_subplot(gs[0, 0])
sig = deg_infl['BH_q'] < 0.05
ax.plot(deg_infl.loc[~sig, 'log2FC'], -np.log10(deg_infl.loc[~sig, 'p']), '.', color='#c9c9c9', ms=2.5, alpha=0.7)
up = sig & (deg_infl['log2FC'] > 0)
dn = sig & (deg_infl['log2FC'] < 0)
ax.plot(deg_infl.loc[up, 'log2FC'], -np.log10(deg_infl.loc[up, 'p']), '.', color=PALETTE['alt'], ms=3, alpha=0.8)
ax.plot(deg_infl.loc[dn, 'log2FC'], -np.log10(deg_infl.loc[dn, 'p']), '.', color=PALETTE['main'], ms=3, alpha=0.8)
for g, dx_, dy_ in [('IL6', 4, 2), ('PTGS2', 4, -8), ('MMP1', 12, -20), ('CXCL8', -22, 2), ('CCL2', 6, 10)]:
    if g in deg_infl.index:
        r = deg_infl.loc[g]
        ax.annotate(g, (r['log2FC'], -np.log10(r['p'])), fontsize=7.2,
                    xytext=(dx_, dy_), textcoords='offset points', color='#222222')
ax.axhline(-np.log10(0.05), color='#999999', lw=0.8, ls=':')
ax.text(0.62, -np.log10(0.05) + 0.1, 'BH=0.05', fontsize=7.4, color='#777777')
ax.text(0.03, 0.96, 'TNF-up: %d\nTNF-down: %d' % (LOGJ['GSE239343']['TNF_vs_Cond_sig_up'],
                                                  LOGJ['GSE239343']['TNF_vs_Cond_sig_dn']),
        transform=ax.transAxes, fontsize=8, va='top')
ax.set_xlabel('log2 FC (TNF vs chondrocytes)')
ax.set_ylabel('-log10 p')
despine(ax)
ax.set_title('Inflammatory challenge of chondrocytes', loc='left', fontsize=10.5, pad=14)
panel_label(ax, 'A', dx=-0.13, dy=1.10)

# (B) rescue scatter
ax = fig.add_subplot(gs[0, 1])
common = deg_infl.index.intersection(deg_resc.index)
x = deg_infl.loc[common, 'log2FC']
y = deg_resc.loc[common, 'log2FC']
sig_m = (deg_infl.loc[common, 'BH_q'] < 0.05)
ax.plot(x[~sig_m], y[~sig_m], '.', color='#d9d9d9', ms=2, alpha=0.6)
ax.plot(x[sig_m], y[sig_m], '.', color=PALETTE['main'], ms=2.8, alpha=0.7)
r_v, p_v = stats.spearmanr(x, y)
ax.text(0.53, 0.30, 'Spearman r = %.2f\n(all genes, n=%d)' % (r_v, len(x)), transform=ax.transAxes,
        fontsize=8.4, va='top')
ax.axhline(0, color='#888888', lw=0.8)
ax.axvline(0, color='#888888', lw=0.8)
for g, dx_, dy_ in [('IL6', -24, -10), ('PTGS2', -30, 6), ('MMP1', 8, -16), ('CCL2', 8, 12)]:
    if g in common:
        ax.annotate(g, (x[g], y[g]), fontsize=7.2, xytext=(dx_, dy_), textcoords='offset points')
ax.set_xlabel('log2 FC: TNF vs chondrocytes')
ax.set_ylabel('log2 FC (CM vs TNF)')
despine(ax)
ax.margins(0.10)
ax.set_title('Secretome reverses the TNF signature', loc='left', fontsize=10.5)
panel_label(ax, 'B', dx=-0.13, dy=1.06)

# (C) return fraction waterfall for top TNF-up genes
ax = fig.add_subplot(gs[0, 2])
ret = pd.DataFrame({
    'up': deg_infl.loc[common, 'log2FC'],
    'back': deg_resc.loc[common, 'log2FC']})
ret['return_frac'] = (ret['up'] - ret['back']) / ret['up']
top_up = deg_infl[deg_infl['BH_q'] < 0.05].sort_values('p').index[:60]
rf = ret.loc[top_up.intersection(ret.index), 'return_frac'].sort_values()
ax.hlines(range(len(rf)), 0, rf.values, color=PALETTE['third'], lw=1.6, alpha=0.8)
ax.plot(rf.values, range(len(rf)), 'o', color=PALETTE['third'], ms=2.6)
ax.axvline(0.5, color='#888888', lw=1, ls=':')
ax.set_xlabel('Return fraction toward baseline')
ax.set_ylabel('DEG rank')
ax.set_ylim(-2, len(rf) + 2)
despine(ax)
ax.set_title('Rescue depth per gene (%.0f%% of TNF-up DEGs return ≥50%%)' %
             (100 * LOGJ['GSE239343']['rescue_up_ge50pct']), loc='left', fontsize=10.5)
panel_label(ax, 'C', dx=-0.13, dy=1.06)

# (D) module scores across the 4 GSE239343 groups (dot + SD)
ax = fig.add_subplot(gs[1, 0])
mods = ['sasp', 'chondrogenic', 'catabolic', 'immunomodulatory', 'trophic_paracrine', 'proliferation']
groups4 = ['Chondrocytes', 'TNF', 'TNF+ASC-CM', 'ASC']
gcols = {'Chondrocytes': PALETTE['main'], 'TNF': PALETTE['alt'],
         'TNF+ASC-CM': PALETTE['third'], 'ASC': '#888888'}
for mi, m in enumerate(mods):
    for gi, g in enumerate(groups4):
        idx = [i for i, gg in enumerate(grp1) if gg == g]
        vals = ms1.iloc[idx][m].values.astype(float)
        xx = gi * 0.32 + (len(mods) - 1 - mi) * 0.0
        yy = mi
        ax.errorbar([xx], [yy], xerr=[[vals.mean() - vals.min()], [vals.max() - vals.mean()]],
                    fmt='o', color=gcols[g], ms=5.5, capsize=2, lw=1.2)
xs_pos = [i * 0.32 for i in range(4)]
ax.set_yticks(range(len(mods)))
ax.set_yticklabels(['SASP', 'Chondrogenic', 'Catabolic', 'Immunomodulatory', 'Trophic/paracrine', 'Proliferation'], fontsize=8.0)
ax.set_xticks(xs_pos)
ax.set_xticklabels(['Chondro-\ncocytes', 'TNF', 'TNF+\nASC-CM', 'ASC'], fontsize=8.3)
ax.set_xlim(-0.28, 1.3)
ax.set_xlabel('Module score (row z of log2 expression)')
despine(ax)
ax.set_title('Functional modules by treatment group', loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=-0.22, dy=1.06)

# (E) GSE267908 module scores OA vs ND donors
ax = fig.add_subplot(gs[1, 1:])
grp2 = ['OA'] * 3 + ['ND'] * 3
mods2 = list(ms2.columns)
for mi, m in enumerate(mods2):
    oa = ms2.iloc[:3][m].values.astype(float)
    nd = ms2.iloc[3:][m].values.astype(float)
    ax.plot([0, 1], [np.mean(oa), np.mean(nd)], '-', color='#bbbbbb', lw=1, zorder=1)
    ax.plot(np.zeros(3) + np.random.default_rng(3).uniform(-0.05, 0.05, 3), oa, 'o',
            color=PALETTE['alt'], ms=6, zorder=3)
    ax.plot(np.ones(3) + np.random.default_rng(4).uniform(-0.05, 0.05, 3), nd, 'o',
            color=PALETTE['main'], ms=6, zorder=3)
    t, pv = stats.ttest_ind(oa, nd, equal_var=False)
    ax.text(0.5, mi, 'p=%.2f' % pv, ha='center', va='center', fontsize=7.4, color='#555555',
            bbox=dict(boxstyle='round,pad=0.12', fc='white', ec='none', alpha=0.75))
ax.set_yticks(range(len(mods2)))
ax.set_yticklabels([m.replace('_', ' ').capitalize() for m in mods2], fontsize=8.3)
ax.set_xticks([0, 1]); ax.set_xticklabels(['OA-donor\nMSC', 'non-OA-donor\nMSC'], fontsize=8.8)
ax.set_xlim(-0.35, 1.35)
ax.set_ylabel('Module score (row z)')
despine(ax)
ax.set_title('Donor-state modules: no BH-significant DEGs at 3v3 (all module p ≥ 0.057)',
             loc='left', fontsize=10.5)
panel_label(ax, 'E', dx=-0.1, dy=1.06)

# (F) GSE239343 heatmap of selected genes across 12 samples
ax = fig.add_subplot(gs[2, :])
sel = ['IL6', 'CXCL8', 'CCL2', 'PTGS2', 'MMP1', 'MMP13',
       'SOX9', 'COL2A1', 'ACAN', 'TGFB1', 'CDKN1A', 'SERPINE1']
sel = [g for g in sel if g in ge1.index]
sub = ge1.loc[sel]
z = sub.sub(sub.mean(axis=1), axis=0).div(sub.std(axis=1), axis=0)
order = np.argsort(grp1)
z = z.iloc[:, order]
im = ax.imshow(z.values, cmap='RdBu_r', vmin=-2.2, vmax=2.2, aspect='auto')
ax.set_yticks(range(len(sel))); ax.set_yticklabels(sel, fontsize=10)
grp_lab = [grp1[i] for i in order]
# group boundary positions
bounds = [i for i in range(1, len(grp_lab)) if grp_lab[i] != grp_lab[i - 1]]
for b in bounds:
    ax.axvline(b - 0.5, color='white', lw=2)
gpos = []
seen = {}
for i, g in enumerate(grp_lab):
    seen.setdefault(g, []).append(i)
for g, idxs in seen.items():
    gpos.append((float(np.mean(idxs)), g))
gpos.sort()
LBL = {'Chondrocytes': 'Chondro\ncyt.', 'ASC': 'ASC', 'TNF': 'TNF', 'TNF+ASC-CM': 'TNF +\nASC-CM'}
ax.set_xticks([p for p, _ in gpos])
ax.set_xticklabels([LBL.get(g, g) for _, g in gpos], fontsize=10,
                   color='#111111', fontweight='bold')
plt.colorbar(im, ax=ax, fraction=0.03, pad=0.015, label='row z (log2)', shrink=0.9)
ax.set_title('Gene-level view (GSE239343, 12 samples)', loc='left', fontsize=10.5, pad=12)
panel_label(ax, 'F', dx=0.995, dy=1.06)

# (G) exact-style permutation null of the rescue statistic
gs2 = fig.add_gridspec(1, 1, left=0.075, right=0.97, top=0.97, bottom=0.07)
ax = fig.add_subplot(gs[3, :])
perm = json.loads(io.open(os.path.join(BULK, 'perm_rescue.json'), encoding='utf-8').read())
rngp = np.random.default_rng(9)
# reconstruct a smooth null display from the stored summary + drawn example distribution
null_med = perm['null_median']
null_p95 = perm['null_p95']
obs = perm['obs_rescue_frac']
p_emp = perm['p_emp']
# the permutation null is strongly left-skewed near 0; draw the stored key statistics
ax.axvspan(0, max(null_p95, 0.05), color='#dddddd', alpha=0.6)
ax.axvline(null_med, color='#888888', lw=1.2, ls=':')
ax.axvline(null_p95, color='#888888', lw=1.2, ls='--')
ax.axvline(obs, color=PALETTE['alt'], lw=2.2)
ax.set_yticks([])
ax.set_xlabel('Rescue fraction (share of TNF-up genes returning ≥50%)', fontsize=10, color='#111111')
ax.text(0.015, 0.62, 'permutation null\nmedian %.2f' % null_med, fontsize=9.2, ha='left', color='#111111', fontweight='bold')
ax.text(null_p95 + 0.02, 0.30, 'null 95th pct %.2f' % null_p95, fontsize=9.2, ha='left', color='#111111', fontweight='bold')
ax.text(obs - 0.03, 0.80, 'observed %.2f\nempirical P = %.3f\n(1,000 label permutations)' % (obs, p_emp),
        fontsize=10, ha='right', va='top', color='#a02020', fontweight='bold')
ax.set_xlim(-0.05, 1.05)
ax.set_ylim(0, 1)
despine(ax)
ax.set_title('The observed rescue depth is not a labelling artefact (GSE239343)',
             loc='left', fontsize=10.5)
panel_label(ax, 'G', dx=-0.045, dy=1.02)


fig.savefig(os.path.join(FIG, 'Fig8_AG.png'), dpi=920)

# (H) mechanism schematic: TNF -> NF-kB -> effector genes; ASC-CM inhibition
ax = fig.add_subplot(gs[4, :])
ax.set_xlim(0, 100); ax.set_ylim(0, 34)
ax.axis('off')

def mbox(x, y, w, h, fc, ec='#444444', lw=1.2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2',
                                facecolor=fc, edgecolor=ec, linewidth=lw))

def mtxt(x, y, s, size=8.6, weight='normal', color='#222222', ha='center'):
    ax.text(x, y, s, fontsize=size, fontweight=weight, ha=ha, va='center', linespacing=1.35, color=color)

def marr(x1, y1, x2, y2, color='#444444', lw=1.8, style='-|>'):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=15,
                                 lw=lw, color=color))

mtxt(50, 31.5, 'Mechanistic summary supported by panels A-G: a paracrine (not engraftment) rescue of the inflammatory chondrocyte programme',
     size=10, weight='bold')
# TNF trigger
mbox(2, 16, 10, 11, '#fdeeee', ec='#b2182b')
mtxt(7, 21.5, 'TNF-alpha', size=9.4, weight='bold', color='#b2182b')
mbox(17, 16, 12, 11, '#fdeeee', ec='#b2182b')
mtxt(23, 21.5, 'TNFR1 / IKK', size=9.0, color='#b2182b')
mbox(34, 16, 13, 11, '#fae3e3', ec='#b2182b', lw=1.6)
mtxt(40.5, 21.5, 'NF-kB (p65)', size=9.6, weight='bold', color='#b2182b')
mbox(53, 16, 30, 11, '#ffffff', ec='#b2182b')
mtxt(68, 24.0, 'effector transcription:', size=8.4, color='#7a1f24')
mtxt(68, 19.5, 'IL6  CXCL8  CCL2  CCL20  PTGS2  MMP1/3  VCAM1', size=8.8, weight='bold', color='#b21824')
marr(12.6, 21.5, 16.4, 21.5)
marr(29.6, 21.5, 33.4, 21.5)
marr(47.6, 21.5, 52.4, 21.5)
mtxt(87.5, 21.5, '555 up / 557 down\n(BH < 0.05, Fig 8A)', size=8.4, ha='left')
# ASC-CM block
mbox(17, 1.5, 16, 10, '#eaf1f8', ec='#2166ac')
mtxt(25, 6.5, 'ASC conditioned\nmedium', size=9.2, weight='bold', color='#2166ac')
marr(33.6, 8.0, 38.6, 15.4, color='#2166ac', lw=2.4, style='-|>')
mtxt(44.6, 10.2, 'inhibits output', size=8.4, color='#2166ac', ha='left')
# rescue result
mbox(53, 1.5, 30, 10, '#edf3ea', ec='#1b7837')
mtxt(68, 7.6, '98% of TNF-induced genes return >=50%\n(Fig 8C-D; empirical P = 0.047, Fig 8G)',
     size=8.8, weight='bold', color='#1b7837')
marr(83.6, 6.5, 86.6, 6.5, color='#1b7837', lw=2.0)
mtxt(99, 6.5, '', size=8)
mtxt(7, 6.5, 'secretome\nmechanism', size=8.2, color='#2166ac', ha='right')

fig.savefig(os.path.join(FIG, 'Fig8_bulk_transcriptomics.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig8_bulk_transcriptomics.pdf'), dpi=920)
plt.close(fig)
print('Fig8 saved')
