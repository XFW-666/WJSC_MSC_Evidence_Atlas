# -*- coding: utf-8 -*-
"""GSE216651 replication pipeline: 4 healthy vs 5 OA IPFP/synovium single-cell samples.
Same QC/annotation as GSE248453; outputs cell-type proportions + fibroblast/MSC marker
subtypes + senescence/SASP modules, donor-level OA vs healthy."""
import os, io, json, gzip
import numpy as np
import pandas as pd
import scanpy as sc
import anndata as ad
import scipy.io
from scipy import sparse as sp
from scipy import stats as sps

BASE = os.path.dirname(os.path.abspath(__file__))
EX = os.path.join(BASE, 'data', 'geo', 'GSE216651_extract')
OUT = os.path.join(BASE, 'results', 'scrna')
LOGP = os.path.join(BASE, 'data', 'replica_pipeline.log')

def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    io.open(LOGP, 'a', encoding='utf-8').write(s + '\n')

# ---------- extract ----------
if not os.path.exists(EX):
    os.makedirs(EX, exist_ok=True)
    import tarfile
    with tarfile.open(os.path.join(BASE, 'data', 'geo', 'GSE216651_RAW.tar')) as tf:
        tf.extractall(EX, filter='data')
log('extracted:', len(os.listdir(EX)))

# ---------- load ----------
files = sorted(os.listdir(EX))
prefixes = sorted(set(f[:-len('_matrix.mtx.gz')] for f in files if f.endswith('_matrix.mtx.gz')))
log('prefixes:', prefixes)
adatas = []
for pref in prefixes:
    mtx = os.path.join(EX, pref + '_matrix.mtx.gz')
    bcs = os.path.join(EX, pref + '_barcodes.tsv.gz')
    feats = os.path.join(EX, pref + '_features.tsv.gz')
    M = sp.csr_matrix(scipy.io.mmread(mtx))
    bc = [ln.strip() for ln in gzip.open(bcs, 'rt').read().splitlines() if ln.strip()]
    feat_tab = pd.read_csv(feats, sep='\t', header=None, dtype=str)
    names = feat_tab[1].tolist() if feat_tab.shape[1] > 1 else feat_tab[0].tolist()
    if M.shape[1] == len(bc) and M.shape[0] != len(bc):
        M = M.T
    if M.shape[0] != len(bc):
        log('shape mismatch', pref, M.shape, len(bc))
        continue
    a = ad.AnnData(X=M, obs=pd.DataFrame(index=[b + '-' + pref for b in bc]),
                   var=pd.DataFrame(index=pd.Index(names, name='gene')))
    a.var_names_make_unique()
    a.obs['sample'] = pref.split('_', 1)[1] if '_' in pref else pref
    adatas.append(a)
    log('loaded', a.obs['sample'][0], a.shape)

def group_of(s):
    return 'healthy' if 'healthy' in s.lower() else 'OA'

adata = ad.concat(adatas, label='sample_id', keys=[a.obs['sample'].iloc[0] for a in adatas], index_unique='-')
adata.obs['group'] = adata.obs['sample'].map(group_of)
log('concat:', adata.shape)

# ---------- QC ----------
adata.var['mt'] = adata.var_names.str.startswith('MT-')
sc.pp.calculate_qc_metrics(adata, qc_vars=['mt'], percent_top=None, log1p=False, inplace=True)
n0 = adata.n_obs
adata = adata[(adata.obs['n_genes_by_counts'] >= 200) & (adata.obs['n_genes_by_counts'] <= 6000) &
              (adata.obs['pct_counts_mt'] <= 20), :]
log('QC: %d -> %d' % (n0, adata.n_obs))
adata.layers['counts'] = adata.X.copy()
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
adata.raw = adata
sc.pp.highly_variable_genes(adata, n_top_genes=3000, batch_key='sample', subset=False)
sc.pp.scale(adata, max_value=10)
sc.tl.pca(adata, n_comps=50, svd_solver='arpack', use_highly_variable=True)
sc.pp.neighbors(adata, n_neighbors=15, n_pcs=30)
sc.tl.leiden(adata, resolution=1.0, key_added='leiden', flavor='igraph', n_iterations=2, directed=False)
sc.tl.umap(adata)
log('clusters:', adata.obs['leiden'].value_counts().to_dict())

# ---------- annotate ----------
MARKERS = {
    'macrophage/monocyte': ['LYZ', 'CD68', 'C1QA', 'C1QB', 'CD14', 'FCGR3A', 'MSR1'],
    'T/NK cell': ['CD3D', 'CD3E', 'TRAC', 'NKG7', 'GNLY', 'CD8A'],
    'B/plasma cell': ['MS4A1', 'CD79A', 'MZB1', 'JCHAIN'],
    'mast cell': ['KIT', 'CPA3', 'TPSAB1'],
    'endothelial cell': ['PECAM1', 'VWF', 'CLDN5', 'CDH5'],
    'pericyte/SMC': ['RGS5', 'ACTA2', 'TAGLN', 'MYH11'],
    'fibroblast/MSC-lineage': ['DCN', 'LUM', 'THY1', 'COL1A1', 'PI16'],
    'adipocyte': ['ADIPOQ', 'PLIN1', 'LPL'],
    'chondrocyte-like': ['COL2A1', 'ACAN', 'CHAD', 'HAPLN1'],
}
scores = pd.DataFrame(index=adata.obs_names)
for k, genes in MARKERS.items():
    ok = [g for g in genes if g in adata.raw.var_names]
    sc.tl.score_genes(adata, gene_list=ok, score_name='sc_' + k.replace('/', '_'), use_raw=True)
    scores['sc_' + k.replace('/', '_')] = adata.obs['sc_' + k.replace('/', '_')].values
scols = ['sc_' + k.replace('/', '_') for k in MARKERS]
best = scores[scols].idxmax(axis=1).str.replace('sc_', '').str.replace('_', '/')
bestv = scores[scols].max(axis=1)
annot = best.where(bestv > 0.2, 'unannotated')
vote = pd.crosstab(adata.obs['leiden'], annot)
adata.obs['cell_type'] = adata.obs['leiden'].map(vote.idxmax(axis=1))
log('cell types:', adata.obs['cell_type'].value_counts().to_dict())

# fibroblast subtypes via marker scores (no re-clustering)
FIB_MARKS = {
    'lining CD55+': ['CD55', 'PI16', 'SFRP2', 'SFRP4'],
    'sublining THY1+': ['THY1', 'CFD', 'RGS1', 'IL6'],
    'MSC-like DKK1/CXCL12+': ['DKK1', 'CXCL12', 'LEPR', 'NT5E'],
    'CD34+ progenitor': ['CD34', 'KDR'],
    'myofibroblast': ['ACTA2', 'MYH10', 'TAGLN'],
}
fibm = (adata.obs['cell_type'] == 'fibroblast/MSC-lineage').values
Xraw = adata.raw.X
gidx = {g: i for i, g in enumerate(adata.raw.var_names)}
fib_scores = {}
for k, genes in FIB_MARKS.items():
    ok = [gidx[g] for g in genes if g in gidx]
    if ok:
        sub = Xraw[fibm][:, ok]
        mu = np.asarray(sub.mean(axis=0)).ravel()
        mu2 = np.asarray(sub.power(2).mean(axis=0)).ravel()
        sd = np.sqrt(np.clip(mu2 - mu ** 2, 0, None))
        sd[sd == 0] = 1
        fib_scores[k] = np.asarray(((sub - mu) / sd).mean(axis=1)).ravel()
fs = pd.DataFrame(fib_scores, index=adata.obs_names[fibm])
fbest = fs.idxmax(axis=1)
fbestv = fs.max(axis=1)
fib_subtype = fbest.where(fbestv > 0.2, 'unclassified')
adata.obs['fib_subtype'] = '-'
adata.obs.loc[fib_subtype.index, 'fib_subtype'] = fib_subtype.values
log('fib subtypes:', fib_subtype.value_counts().to_dict())

# ---------- proportions OA vs healthy ----------
samples = sorted(adata.obs['sample'].unique())
prop = {}
for ct in adata.obs['cell_type'].value_counts().index:
    prop[ct] = {s: 100.0 * (adata.obs.loc[adata.obs['sample'] == s, 'cell_type'] == ct).mean() for s in samples}
prop = pd.DataFrame(prop).T
prop.to_csv(os.path.join(OUT, 'replica_per_sample_proportions.csv'))
oa_s = [s for s in samples if group_of(s) == 'OA']
he_s = [s for s in samples if group_of(s) == 'healthy']
da_rows = []
for ct in prop.index:
    a_ = prop.loc[ct, oa_s].values.astype(float)
    b_ = prop.loc[ct, he_s].values.astype(float)
    u, pv = sps.mannwhitneyu(a_, b_, alternative='two-sided')
    da_rows.append({'cell_type': ct, 'mean_OA': a_.mean(), 'mean_healthy': b_.mean(),
                    'log2FC_OA_vs_healthy': np.log2((a_.mean() + 0.1) / (b_.mean() + 0.1)), 'MWU_p': pv})
da = pd.DataFrame(da_rows).sort_values('MWU_p')
da.to_csv(os.path.join(OUT, 'replica_diff_abundance.csv'), index=False)

# ---------- senescence/SASP modules ----------
MODS = {
    'senescence_core': ['CDKN1A', 'CDKN2A', 'CDKN2B', 'SERPINE1', 'GLB1', 'GADD45A', 'GADD45B', 'MDM2', 'BAX', 'PMAIP1'],
    'sasp': ['IL6', 'CXCL8', 'CCL2', 'CCL20', 'CXCL1', 'CXCL2', 'CXCL3', 'IL1B', 'MMP1', 'MMP3',
             'MMP10', 'MMP13', 'MMP14', 'TIMP1', 'TIMP2', 'IGFBP3', 'IGFBP4', 'IGFBP5', 'PLAU', 'PLAUR',
             'VCAM1', 'ICAM1', 'PTGS2'],
}
mu = np.asarray(Xraw.mean(axis=0)).ravel()
mu2 = np.asarray(Xraw.power(2).mean(axis=0)).ravel()
sd = np.sqrt(np.clip(mu2 - mu ** 2, 0, None))
sd[sd == 0] = 1
for m, genes in MODS.items():
    ok = [gidx[g] for g in genes if g in gidx]
    Z = (Xraw[:, ok] - mu[ok]) / sd[ok]
    adata.obs['mod_' + m] = np.asarray(Z.mean(axis=1)).ravel()

donor_mod = []
for ct in ['fibroblast/MSC-lineage', 'macrophage/monocyte']:
    for m in MODS:
        vals = {s: float(adata.obs.loc[(adata.obs['sample'] == s) & (adata.obs['cell_type'] == ct), 'mod_' + m].mean())
                if ((adata.obs['sample'] == s) & (adata.obs['cell_type'] == ct)).sum() >= 10 else np.nan
                for s in samples}
        a_ = np.array([vals[s] for s in oa_s], dtype=float)
        b_ = np.array([vals[s] for s in he_s], dtype=float)
        u, pv = sps.mannwhitneyu(a_[~np.isnan(a_)], b_[~np.isnan(b_)], alternative='two-sided')
        donor_mod.append({'cell_type': ct, 'module': m, 'mean_OA': float(np.nanmean(a_)),
                          'mean_healthy': float(np.nanmean(b_)), 'MWU_p': pv})
pd.DataFrame(donor_mod).to_csv(os.path.join(OUT, 'replica_module_donor_stats.csv'), index=False)

# fib subtypes OA vs healthy (donor-level share within fibroblast compartment)
fibsub_rows = []
for st in sorted(set(fib_subtype.values)):
    row = {'subtype': st}
    for s in samples:
        fib_cells = adata.obs[(adata.obs['sample'] == s) & (adata.obs['cell_type'] == 'fibroblast/MSC-lineage')]
        row[s] = 100.0 * (fib_cells['fib_subtype'] == st).mean() if len(fib_cells) else np.nan
    a_ = np.array([row[s] for s in oa_s], dtype=float)
    b_ = np.array([row[s] for s in he_s], dtype=float)
    u, pv = sps.mannwhitneyu(a_[~np.isnan(a_)], b_[~np.isnan(b_)], alternative='two-sided')
    row['mean_OA'] = float(np.nanmean(a_)); row['mean_healthy'] = float(np.nanmean(b_)); row['MWU_p'] = pv
    fibsub_rows.append(row)
pd.DataFrame(fibsub_rows).to_csv(os.path.join(OUT, 'replica_fib_subtypes.csv'), index=False)

adata.write(os.path.join(OUT, 'GSE216651_processed.h5ad'), compression='gzip')
metrics = {'n_cells': int(adata.n_obs), 'samples': {s: group_of(s) for s in samples},
           'cells_per_sample': adata.obs['sample'].value_counts().to_dict(),
           'cell_types': adata.obs['cell_type'].value_counts().to_dict()}
io.open(os.path.join(OUT, 'replica_metrics.json'), 'w', encoding='utf-8').write(
    json.dumps(metrics, indent=1, default=str))
log('REPLICA DONE')
