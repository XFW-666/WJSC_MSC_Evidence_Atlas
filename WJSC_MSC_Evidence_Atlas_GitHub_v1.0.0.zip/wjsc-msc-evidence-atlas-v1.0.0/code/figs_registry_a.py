# -*- coding: utf-8 -*-
"""Fig 2 (registry landscape) and Fig 3 (trial design). No bar charts; 600 DPI."""
import io, os, json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import squarify
from figstyle import (plt, PALETTE, FAMILY_ORDER, FAMILY_COLORS, FAMILY_SHORT,
                      despine, panel_label)

BASE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.join(BASE, 'results', 'registry')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)

df = pd.read_csv(os.path.join(REG, 'trials_ortho_clean.csv'), dtype=str)
df['phase'] = df['phase'].replace({'NA': 'not applicable'})
df['enrollment_num'] = pd.to_numeric(df['enrollment'], errors='coerce')
df['start_year'] = df['start'].map(lambda s: int(str(s)[:4]) if isinstance(s, str) and str(s)[:4].isdigit() else None)
A = json.loads(io.open(os.path.join(REG, 'registry_analysis.json'), encoding='utf-8').read())

fam_of = df['family'].copy()
fam_of = fam_of.map(lambda f: FAMILY_SHORT.get(f, f))
fam_order_short = [FAMILY_SHORT[f] for f in FAMILY_ORDER if f in set(df['family'])]
fam_colors = [FAMILY_COLORS[FAMILY_ORDER.index(f)] for f in FAMILY_ORDER if f in set(df['family'])]

# ================= FIG 2 =================
fig = plt.figure(figsize=(11, 7.2))
gs = fig.add_gridspec(2, 2, hspace=0.30, wspace=0.15, left=0.07, right=0.97, top=0.93, bottom=0.08)

# (A) trials per start year — line+fill
ax = fig.add_subplot(gs[0, 0])
yper = pd.Series({int(k): v for k, v in A['trials_per_year'].items()}).sort_index()
yper = yper.reindex(range(2000, 2027), fill_value=0)
ax.fill_between(yper.index, yper.values, color=PALETTE['main'], alpha=0.18)
ax.plot(yper.index, yper.values, color=PALETTE['main'], lw=1.8)
ax.set_ylabel('Registered trials')
ax.set_xlabel('Start year')
ax.text(2019.2, 41, 'peak: 40', fontsize=9, color=PALETTE['alt'])
despine(ax)
ax.set_title('Registrations over time (n=412)', loc='left', fontsize=10.5)
panel_label(ax, 'A', dy=1.06)

# (B) condition families: greedy circle packing (bubble treemap)
ax = fig.add_subplot(gs[0, 1])
ax.set_xlim(-10.5, 10.5); ax.set_ylim(-10.5, 10.5)
ax.set_aspect('equal')
ax.axis('off')
fam_items = [(f, A['family_counts'].get(f, 0)) for f in FAMILY_ORDER if A['family_counts'].get(f, 0) > 0]
fam_items.sort(key=lambda kv: -kv[1])
tot = sum(n for _, n in fam_items)
RMAX = 4.6
radii = {f: RMAX * (n / tot) ** 0.5 * 2.05 for f, n in fam_items}
placed = []
def overlaps(x, y, r):
    for (px, py, pr) in placed:
        if (x - px) ** 2 + (y - py) ** 2 < (r + pr + 0.12) ** 2:
            return True
    return False
f0, n0 = fam_items[0]
placed.append((0.0, 0.0, radii[f0]))
for f, n in fam_items[1:]:
    r = radii[f]
    best = None
    for (px, py, pr) in placed:
        for a in np.linspace(0, 2 * np.pi, 24, endpoint=False):
            x = px + (pr + r + 0.12) * np.cos(a)
            y = py + (pr + r + 0.12) * np.sin(a)
            if abs(x) + r > 10.2 or abs(y) + r > 10.2:
                continue
            if overlaps(x, y, r):
                continue
            d = x * x + y * y
            if best is None or d < best[0]:
                best = (d, x, y)
    if best:
        placed.append((best[1], best[2], r))
for (f, n) in fam_items:
    for (x, y, r) in placed:
        if abs(r - radii[f]) < 1e-6:
            c = FAMILY_COLORS[FAMILY_ORDER.index(f)]
            ax.add_patch(plt.Circle((x, y), r, facecolor=c, alpha=0.88, edgecolor='white', lw=1.6))
            lum = sum(int(c[j:j + 2], 16) for j in (1, 3, 5)) / 3
            tc = 'white' if lum < 150 else '#222222'
            short = FAMILY_SHORT[f]
            pct = 100.0 * n / A['n_trials']
            WRAP = {'Osteonecrosis': 'Osteo-\nnecrosis', 'Cartilage defect': 'Cartilage\ndefect',
                    'Tendon/ligament/meniscus': 'Tendon/\nligament/\nmeniscus',
                    'Fracture/bone defect': 'Fracture/\nbone defect',
                    'Other osteoarthritis': 'Other\nOA'}
            name_wrapped = WRAP.get(short, short.replace('/', '/\n') if len(short) > 14 else short)
            if r > 2.0:
                ax.text(x, y, '%s\n%d (%.0f%%)' % (name_wrapped, n, pct),
                        ha='center', va='center', fontsize=8.4 if r > 2.9 else 7.4,
                        color=tc, linespacing=1.25, zorder=5)
            elif r > 1.2:
                ax.text(x, y, '%s\n%d' % (name_wrapped, n), ha='center', va='center',
                        fontsize=6.6, color=tc, linespacing=1.15, zorder=5)
            else:
                TINY_OFFSETS = {'Osteoporosis': (-1.15, -1.15), 'Hip OA': (0.0, 1.15)}
                dx_, dy_ = TINY_OFFSETS.get(short, (0.0, 0.35))
                va_ = 'top' if dy_ < 0 else 'bottom'
                ax.text(x + dx_, y + r + dy_, '%s %d' % (short, n), ha='center', va=va_,
                        fontsize=7.2, color='#111111', zorder=6,
                        bbox=dict(boxstyle='round,pad=0.12', fc='white', ec='none', alpha=0.85))
            break
ax.text(0, -10.15, 'bubble area proportional to registered trials', size=8, color='#333333', ha='center')
ax.set_title('Condition families (n=412)', loc='left', fontsize=10.5)
panel_label(ax, 'B', dx=0.0, dy=1.04)

# (C) countries dot plot (top 14)
ax = fig.add_subplot(gs[1, 0])
geo = A['countries']
top = list(geo.items())[:14][::-1]
names = [k for k, v in top]
vals = [v for k, v in top]
y = np.arange(len(names))
ax.hlines(y, 0, vals, color=PALETTE['main'], alpha=0.35, lw=2)
ax.plot(vals, y, 'o', color=PALETTE['main'], ms=6)
ax.set_yticks(y); ax.set_yticklabels(names, fontsize=9)
ax.set_xlabel('Trial sites (lead/collaborating countries)')
despine(ax)
ax.set_title('Geography (top 14 of %d countries)' % len(geo), loc='left', fontsize=10.5)
panel_label(ax, 'C', dx=-0.22, dy=1.06)

# (D) alluvial: condition family -> registry status
ax = fig.add_subplot(gs[1, 1])
ax.set_xlim(0, 100); ax.set_ylim(0, 100)
ax.axis('off')
status_order = ['completed', 'active', 'discontinued', 'unknown status']
status_cols = {'completed': '#2166ac', 'active': '#92c5de',
               'discontinued': '#b2182b', 'unknown status': '#bdbdbd'}
fams_present = [f for f in FAMILY_ORDER if f in set(df['family'])]
fams2 = list(fams_present)
fam_n = {f: A['family_counts'].get(f, 0) for f in fams2}
fam_status = {}
for f in fams2:
    sub = df[df['family'] == f]
    fam_status[f] = {s: int(((sub['status'] == 'COMPLETED') if s == 'completed' else
                             (sub['status'].isin(['RECRUITING', 'ACTIVE_NOT_RECRUITING', 'ENROLLING_BY_INVITATION', 'NOT_YET_RECRUITING', 'AVAILABLE'])) if s == 'active' else
                             (sub['status'].isin(['TERMINATED', 'WITHDRAWN', 'SUSPENDED', 'NO_LONGER_AVAILABLE'])) if s == 'discontinued' else
                             (sub['status'] == 'UNKNOWN')).sum()) for s in status_order}
def ribbon2(x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.5):
    from matplotlib.path import Path as MPath
    dx = (x1 - x0) * 0.42
    verts = [(x0, y0a), (x0 + dx, y0a), (x1 - dx, y1a), (x1, y1a),
             (x1, y1b), (x1 - dx, y1b), (x0 + dx, y0b), (x0, y0b), (x0, y0a)]
    codes = [MPath.MOVETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4,
             MPath.LINETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4, MPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MPathRaw(verts, codes), facecolor=color, edgecolor='none', alpha=alpha))
from matplotlib.patches import PathPatch, Path as MPathRaw
H = 86.0
ytop = 94.0
yl = ytop
yr = ytop
for f in fams2:
    n = fam_n[f]
    hl = H * n / A['n_trials']
    c = FAMILY_COLORS[FAMILY_ORDER.index(f)]
    ax.add_patch(plt.Rectangle((4, yl - hl), 1.6, hl, facecolor=c, edgecolor='none'))
    if n >= 10:
        ax.text(2.6, yl - hl / 2, '%s %d' % (FAMILY_SHORT[f], n), ha='right', va='center', fontsize=7.4)
    yr2 = yr
    for s in status_order:
        k = fam_status[f][s]
        if k == 0:
            continue
        hr = H * k / A['n_trials']
        ribbon2(5.6, yl - hl * k / n, yl, 93.0, yr2 - hr, yr2, status_cols[s], alpha=0.45)
        yr2 -= hr
    yl -= hl
for s in status_order:
    n = int((df['status'].map(lambda x: (x == 'COMPLETED') if s == 'completed' else
                             (x in ('RECRUITING', 'ACTIVE_NOT_RECRUITING', 'ENROLLING_BY_INVITATION', 'NOT_YET_RECRUITING', 'AVAILABLE')) if s == 'active' else
                             (x in ('TERMINATED', 'WITHDRAWN', 'SUSPENDED', 'NO_LONGER_AVAILABLE')) if s == 'discontinued' else
                             (x == 'UNKNOWN')).sum()))
    h = H * n / A['n_trials']
    ax.add_patch(plt.Rectangle((93.0, yr - h), 1.6, h, facecolor=status_cols[s], edgecolor='none'))
    ax.text(95.6, yr - h / 2, '%s %d' % (s, n), ha='left', va='center', fontsize=7.6)
    yr -= h
ax.text(5.6, 97.5, 'condition family', size=8.2, color='#555555', ha='left', va='center')
ax.text(93.0, 97.5, 'registry status', size=8.2, color='#555555', ha='left', va='center')
ax.set_title('Family-to-status flow (width = trials)', loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=0.02, dy=1.1)

fig.savefig(os.path.join(FIG, 'Fig2_registry_landscape.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig2_registry_landscape.pdf'), dpi=920)
plt.close(fig)
print('Fig2 saved')

# ================= FIG 3 =================
fig = plt.figure(figsize=(11, 9.4))
gs = fig.add_gridspec(2, 2, hspace=0.32, wspace=0.18, left=0.1, right=0.96, top=0.93, bottom=0.1)

# (A) development-phase funnel flow (band height = trials)
ax = fig.add_subplot(gs[0, 0])
ph_order = ['EARLY_PHASE1', 'PHASE1', 'PHASE1,PHASE2', 'PHASE2', 'PHASE2,PHASE3', 'PHASE3', 'PHASE4', 'not applicable']
ph_labels = ['Early ph. 1', 'Phase 1', 'Phase 1/2', 'Phase 2', 'Phase 2/3', 'Phase 3', 'Phase 4', 'N/A phase']
vals = [A['phase_counts'].get(p_, 0) for p_ in ph_order]
total_ph = sum(vals)
ax.set_xlim(0, 100); ax.set_ylim(-4, 104); ax.axis('off')
H = 96.0; y0 = 98.5
col_ph = plt.cm.BuGn(np.linspace(0.35, 0.85, len(ph_order)))
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
y = y0
yf = y0
for lab, v, c in zip(ph_labels, vals, col_ph):
    h = H * v / total_ph
    ax.add_patch(plt.Rectangle((34, y - h), 2.6, h, facecolor=c, edgecolor='none'))
    ax.text(37.2, y - h / 2, '%s  %d' % (lab, v), ha='left', va='center', fontsize=9.4,
            color='#222222', fontweight='bold')
    dxs = (34 - 8.2) * 0.42
    verts = [(8.2, yf), (8.2 + dxs, yf), (34 - dxs, y - h / 2), (34, y - h / 2),
             (34, y - h / 2 + h * 0.35), (34 - dxs, y - h / 2 + h * 0.35), (8.2 + dxs, yf - h),
             (8.2, yf - h), (8.2, yf)]
    ax.add_patch(PathPatch(MPath(verts, [MPath.MOVETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4,
                                         MPath.LINETO, MPath.CURVE4, MPath.CURVE4, MPath.CURVE4,
                                         MPath.CLOSEPOLY]),
                           facecolor='#4d8f4d', edgecolor='none', alpha=0.28))
    y -= h
    yf -= h
ax.text(8.2, 102.5, 'all trials 412', ha='center', fontsize=9.0, color='#2e7d32', fontweight='bold')
ax.set_title('Development phase funnel (band height = trials)', loc='left', fontsize=10.5)

# (B) cell source x family heatmap of counts
ax = fig.add_subplot(gs[0, 1])
srcs = ['bone marrow', 'adipose tissue', 'umbilical cord', 'synovial', 'other/unspecified']
src_cols = [PALETTE['bm'], PALETTE['ad'], PALETTE['uc'], PALETTE['syn'], PALETTE['unspec']]
mat = np.zeros((len(fams_present), len(srcs)))
for i, f in enumerate(fams_present):
    sub = df[df['family'] == f]
    for j, s in enumerate(srcs):
        mat[i, j] = (sub['source'] == s).sum()
im = ax.imshow(mat, cmap='Blues', aspect='auto')
for i in range(len(fams_present)):
    for j in range(len(srcs)):
        v = int(mat[i, j])
        if v:
            ax.text(j, i, str(v), ha='center', va='center', fontsize=8,
                    color='white' if v > mat.max() * 0.55 else '#222222')
ax.set_xticks(range(len(srcs)))
ax.set_xticklabels(['BM', 'Adipose', 'UC', 'Synovial', 'Unspec.'], fontsize=9)
ax.set_yticks(range(len(fams_present)))
ax.set_yticklabels([FAMILY_SHORT[f] for f in fams_present], fontsize=8.5)
plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02, label='Trials')
ax.set_title('Cell source by condition family', loc='left', fontsize=10.5)
panel_label(ax, 'B', dx=-0.16, dy=1.06)

# (C) origin bubble timeline (year x origin class, bubble = trials)
ax = fig.add_subplot(gs[1, 0])
yr = df.dropna(subset=['start_year']).copy()
yr = yr[(yr['start_year'] >= 2005) & (yr['start_year'] <= 2026)]
rows = [('autologous', 'Autologous', PALETTE['main'], 2),
        ('allogeneic', 'Allogeneic', PALETTE['alt'], 1),
        ('not specified', 'Not specified', '#54606e', 0)]
ymax = 0
for key, lab, colr, yrow in rows:
    cnt = yr[yr['origin'] == key].groupby('start_year').size()
    cnt = cnt.reindex(range(2005, 2027), fill_value=0)
    xs = cnt.index.values.astype(float)
    vals = cnt.values.astype(float)
    # smoothed guide line (3-year rolling mean)
    if vals.sum() > 0:
        roll = np.convolve(vals, np.ones(3) / 3, mode='same')
        roll[0] = (vals[0] + vals[1]) / 2 if len(vals) > 1 else vals[0]
        roll[-1] = (vals[-2] + vals[-1]) / 2 if len(vals) > 1 else vals[-1]
        ax.plot(xs, yrow + roll / 26.0, color=colr, lw=1.2, alpha=0.45, zorder=2)
    for x, v in zip(xs, vals):
        if v > 0:
            ax.scatter([x], [yrow + v / 26.0], s=22 + 62 * v, color=colr,
                       alpha=0.75, edgecolors='white', linewidths=0.7, zorder=3)
    ymax = max(ymax, (vals.max() / 26.0) if len(vals) else 0)
ax.set_yticks([2, 1, 0])
ax.set_yticklabels([r[1] for r in rows], fontsize=9)
ax.set_xlim(2004.4, 2026.6)
ax.set_ylim(-0.35, 2.95)
ax.set_xlabel('Start year')
for xlab, ypos in [('n autologous', 2.62), ('n allogeneic', 1.62), ('n not specified', 0.62)]:
    ax.text(2005.0, ypos, xlab, fontsize=8.2, color='#222222', ha='left', fontweight='bold')
despine(ax)
ax.set_title('Cell origin over time (bubble = trials started)', loc='left', fontsize=10.5, color='#222222')
panel_label(ax, 'C', dx=-0.12, dy=1.06)

# (D) product manipulation class — nested rings with keyed legend (no radial labels to collide)
ax = fig.add_subplot(gs[1, 1])
prod = A['product_counts']
cats_d = [('not specified', prod.get('not specified', 0), '#c9c9c9'),
          ('point-of-care / minimally manipulated', prod.get('point-of-care / minimally manipulated', 0), PALETTE['warm']),
          ('culture-expanded', prod.get('culture-expanded', 0), PALETTE['main'])]
tot_d = A['n_trials']
import matplotlib.patches as mpatches
start = 90.0
for lab, v, c in cats_d:
    th = 360.0 * v / tot_d
    wedge = mpatches.Wedge((0, 0), 1.0, start - th, start, width=0.34,
                           facecolor=c, edgecolor='white', lw=1.5)
    ax.add_patch(wedge)
    am = np.deg2rad(start - th / 2)
    ax.text(0.83 * np.cos(am), 0.83 * np.sin(am), '%d\n(%.0f%%)' % (v, 100 * v / tot_d),
            ha='center', va='center', fontsize=9.0,
            color='#111111', fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.16', fc='white', ec='#333333', lw=0.6))
    start -= th
ax.add_patch(mpatches.Circle((0, 0), 0.60, facecolor='#ffffff', edgecolor='#333333', lw=1.2))
ax.text(0, 0.20, '412 trials', ha='center', va='center', fontsize=10.5, fontweight='bold')
ax.text(0, -0.16, 'product\nmanipulation', ha='center', va='center', fontsize=8.6,
        color='#222222', fontweight='bold', linespacing=1.15)
handles_d = [mpatches.Patch(facecolor=c, edgecolor='#333333', lw=0.6,
                            label='%s - %d (%.0f%%)' % (lab, v, 100.0 * v / tot_d))
             for lab, v, c in cats_d]
ax.legend(handles=handles_d, loc='upper center', bbox_to_anchor=(0.5, -0.01),
          fontsize=8.4, frameon=True, framealpha=0.95, edgecolor='#333333',
          title='product manipulation class', title_fontsize=8.8, borderpad=0.55)
ax.set_xlim(-1.30, 1.30); ax.set_ylim(-1.85, 1.30)
ax.set_aspect('equal'); ax.axis('off')
ax.set_title('Product manipulation class (ring segment = trials)', loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=-0.02, dy=1.02)

fig.savefig(os.path.join(FIG, 'Fig3_trial_design.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig3_trial_design.pdf'), dpi=920)
plt.close(fig)
print('Fig3 saved')
