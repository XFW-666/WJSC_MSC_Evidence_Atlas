# -*- coding: utf-8 -*-
"""Fig 1 rebuild: graphical abstract - knee anatomy + injection + niche zoom +
registry alluvial flow + evidence-layer cards."""
import os, json, io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import (FancyBboxPatch, Polygon, Circle, Ellipse, FancyArrowPatch, Wedge, PathPatch)
from matplotlib.path import Path
from figstyle import plt, PALETTE

BASE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.join(BASE, 'results', 'registry')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)
A = json.loads(io.open(os.path.join(REG, 'registry_analysis.json'), encoding='utf-8').read())

fig, ax = plt.subplots(figsize=(13.2, 9.4))
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')
rng = np.random.default_rng(4)


def txt(x, y, s, size=9, color='#222222', weight='normal', ha='center', va='center', ls=1.3):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va, linespacing=ls)


def card(x, y, w, h, fc, ec='#333333', lw=1.2, r=2.0):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.5,rounding_size=%.1f' % r,
                                facecolor=fc, edgecolor=ec, linewidth=lw))


def ribbon(x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.55):
    """bezier alluvial ribbon between two vertical spans"""
    dx = (x1 - x0) * 0.45
    verts = [(x0, y0a), (x0 + dx, y0a), (x1 - dx, y1a), (x1, y1a),
             (x1, y1b), (x1 - dx, y1b), (x0 + dx, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4,
             Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), facecolor=color, edgecolor='none', alpha=alpha))


txt(50, 97.5, 'MSC therapy for musculoskeletal disorders: what trials assume vs what public data show',
    size=13, weight='bold')

# ================= LEFT: knee joint schematic =================
LX0, LY0 = 2, 8
card(LX0, LY0, 42, 74, '#fbfbfd', ec='#666666', lw=1.3)
txt(LX0 + 21, 78.5, 'The joint the cell enters', size=11, weight='bold')

# femur (top)
femur = Polygon([(14, 68), (32, 68), (34, 58), (31.5, 52), (29, 50.5),
                 (25.5, 53.5), (20.5, 53.5), (17, 50.5), (14.5, 58)],
                closed=True, facecolor='#e8e2d5', edgecolor='#8a7f66', lw=1.4, zorder=3)
ax.add_patch(femur)
# cartilage caps on condyles
for cx in (21.4, 27.6):
    ax.add_patch(Wedge((cx, 52.6), 3.4, 200, 340, facecolor='#cfe4f2', edgecolor='#7fa6c4', lw=1.0, zorder=4))
# tibia (bottom)
tibia = Polygon([(13.5, 44.5), (32.5, 44.5), (31, 43.2), (30.2, 36), (30.8, 24),
                 (15.2, 24), (15.8, 36), (15, 43.2)], closed=True,
                facecolor='#e8e2d5', edgecolor='#8a7f66', lw=1.4, zorder=3)
ax.add_patch(tibia)
# tibial cartilage
ax.add_patch(Polygon([(14.2, 44.6), (31.8, 44.6), (31.4, 43.4), (14.6, 43.4)], closed=True,
                     facecolor='#cfe4f2', edgecolor='#7fa6c4', lw=1.0, zorder=4))
# menisci
ax.add_patch(Polygon([(15, 44.5), (20.5, 43.6), (15.4, 43.4)], closed=True,
                     facecolor='#f2e3b8', edgecolor='#b39b52', lw=1.0, zorder=5))
ax.add_patch(Polygon([(31, 44.5), (25.5, 43.6), (30.6, 43.4)], closed=True,
                     facecolor='#f2e3b8', edgecolor='#b39b52', lw=1.0, zorder=5))
# joint space band
ax.add_patch(Polygon([(14.8, 50.6), (31.2, 50.6), (31.4, 44.6), (14.6, 44.6)], closed=True,
                     facecolor='#f7f4fa', edgecolor='none', alpha=0.7, zorder=1))
# synovium lining (inflamed) along joint capsule
syn_y = [50.6 - 1.4 * np.abs(np.sin(np.linspace(0, np.pi, 40))) for _ in [0]][0]
xs = np.linspace(12.2, 34.4, 60)
ys = 47.6 + 2.4 * np.sin((xs - 12.2) / 22.2 * np.pi)
ax.plot(xs, ys, color='#d66a8f', lw=3.2, zorder=6, solid_capstyle='round')
ax.text(12.6, 55.4, 'synovium / capsule', fontsize=8.4, color='#b03a64', style='italic', ha='left')
# fibroblast + macrophage dots inside synovium
for i in range(14):
    x = 14 + 16 * (i / 13.0)
    y = 47.4 + 2.3 * np.sin((x - 12.2) / 22.2 * np.pi) + rng.uniform(-1.0, 1.0)
    c = PALETTE['main'] if i % 3 else PALETTE['alt']
    ax.scatter([x], [y], s=46, color=c, edgecolors='white', linewidths=0.7, zorder=7)

# syringe + injection arrow
sx, sy = 40.5, 63
ax.add_patch(FancyBboxPatch((sx, sy), 5.6, 13, boxstyle='round,pad=0.3,rounding_size=1',
                            facecolor='#dddddd', edgecolor='#555555', lw=1.2))
ax.plot([sx, sx + 5.6], [sy + 9.4, sy + 9.4], color='#888888', lw=1.0)
ax.add_patch(Polygon([(sx, sy), (sx, sy + 1.6), (sx + 1.6, sy + 0.8)], closed=True,
                     facecolor='#aaaaaa', edgecolor='none'))
ax.add_patch(FancyArrowPatch((sx + 2.8, sy - 0.4), (28.5, 49.6),
                             connectionstyle='arc3,rad=0.25', arrowstyle='-|>',
                             mutation_scale=17, lw=2.0, color='#c0392b'))
txt(43.6, 66.5, 'intra-articular\ninjection', size=8.6, ha='left', weight='bold')
txt(43.6, 58.0, 'numeric cell dose stated\nin only %.1f%% of trials;\nspan = %d-fold' % (
    100 * A['dose_share_of_with_n'], round(A['dose_fold_range'])), size=8.2, ha='left', color='#c0392b')

# ---- zoom bubble: synovial niche detail (bottom-left inside card) ----
zx, zy, zr = 23, 21, 11.5
ax.add_patch(Circle((zx, zy), zr, facecolor='#ffffff', edgecolor='#b03a64', lw=1.8, zorder=9))
ax.plot([26.5, zx - zr * 0.7], [47.0, zy + zr * 0.75], color='#b03a64', lw=1.0, ls=':', zorder=8)
txt(zx, zy + zr - 1.6, 'niche (zoom)', size=8.8, weight='bold', color='#b03a64')
# fibroblasts (blue ellipses) + macrophage (red) + APOE arrow
fib_pos = [(zx - 5.2, zy + 2.0), (zx - 1.4, zy + 4.4), (zx + 2.6, zy + 2.4),
           (zx - 3.4, zy - 1.6), (zx + 0.8, zy - 0.4)]
for (fx, fy) in fib_pos:
    ax.add_patch(Ellipse((fx, fy), 3.2, 2.0, facecolor=PALETTE['main'], edgecolor='white', lw=1.0, zorder=10))
mac_pos = [(zx + 5.0, zy - 2.6), (zx - 5.6, zy - 4.0)]
for (mx, my) in mac_pos:
    ax.add_patch(Ellipse((mx, my), 3.0, 2.6, facecolor=PALETTE['alt'], edgecolor='white', lw=1.0, zorder=10))
ax.add_patch(FancyArrowPatch((zx + 4.4, zy - 3.0), (zx + 1.6, zy + 1.4),
                             connectionstyle='arc3,rad=-0.3', arrowstyle='-|>',
                             mutation_scale=12, lw=1.5, color='#7d3c98', zorder=11))
txt(zx + 6.6, zy - 5.6, 'APOE→LRP1\nP = 0.001', size=7.4, color='#7d3c98', ha='right')
txt(zx - 4.6, zy + 5.9, 'THY1+/DKK1+\nfibroblasts', size=7.6, color=PALETTE['main'])
txt(zx + 6.2, zy + 5.4, 'macrophages', size=7.6, color=PALETTE['alt'], ha='right')
txt(zx, zy - zr + 2.4, 'high pain: fibroblasts 66.6%\nvs 40.1% (P = 0.029)', size=7.9, color='#333333')

# ================= RIGHT TOP: registry alluvial card =================
RX = 48
card(RX, 56, 50, 26, '#eaf1f8', ec='#2166ac', lw=1.4)
txt(RX + 25, 79.6, 'Layer 1 — The registered programme', size=11, weight='bold', color=PALETTE['main'])

# alluvial: 642 -> 412 -> status
x0, x1, x2 = RX + 4, RX + 20, RX + 46
def col(x, total, n, y0, w=3.0, label='', color='#333', val=''):
    h = 20.0 * n / total if total else 0
    ax.add_patch(plt.Rectangle((x, y0), w, h, facecolor=color, edgecolor='none'))
    return h
# stage 1
ytop = 74.5
h642 = 15.0
ax.add_patch(plt.Rectangle((x0, ytop - h642), 3, h642, facecolor='#9dbfe0', edgecolor='none'))
txt(x0 - 1.2, ytop - h642 / 2, '642\ncandidate\nrecords', size=7.6, ha='right')
# stage 2: 412 included vs 230 excluded
h412 = 15.0 * 412 / 642
h230 = 15.0 - h412
ribbon(x0 + 3, ytop - h642, ytop - h642 + h412, x1, ytop - h412, ytop, '#7fb069', alpha=0.5)
ribbon(x0 + 3, ytop - h642 + h412, ytop, x1, ytop - h412 - h230, ytop - h412, '#c0392b', alpha=0.35)
ax.add_patch(plt.Rectangle((x1, ytop - h412), 3, h412, facecolor='#4a8bc2', edgecolor='none'))
txt(x1 + 1.5, ytop + 1.9, '412 analytic trials', size=7.8, weight='bold')
txt((x0 + x1) / 2, ytop - h412 - h230 / 2 + 0.3, '230 excluded\n(not MSK-specific)', size=6.8,
    color='#a04040', ha='center')
# stage 3: status ribbons
st = A['status_groups']
order = [('completed', 'completed 167', '#2166ac'), ('active', 'active 82', '#92c5de'),
         ('discontinued', 'discontinued 42', '#b2182b'), ('unknown status', 'unknown 121', '#9e9e9e')]
yy = ytop
yy2 = ytop
for key, lab, colr in order:
    n = st[key]
    h = 15.0 * n / 412
    ribbon(x1 + 3, yy - h, yy, x2, yy2 - h, yy2, colr, alpha=0.55)
    ax.add_patch(plt.Rectangle((x2, yy2 - h), 3, h, facecolor=colr, edgecolor='none'))
    txt(x2 + 4.6, yy2 - h / 2, lab, size=7.4, ha='left')
    yy -= h
    yy2 -= h
txt(RX + 25, 57.6, 'condition-scoped API v2 search (9 queries, 21 Sep 2026)', size=7.6, color='#555555')

# ================= RIGHT MIDDLE: bulk datasets card =================
card(RX, 34, 50, 19.5, '#fdeeee', ec='#b2182b', lw=1.4)
txt(RX + 25, 51.0, 'Layer 2 — The therapeutic cell', size=11, weight='bold', color=PALETTE['alt'])
txt(RX + 2.4, 47.0, 'GSE267908  OA-donor vs non-OA BM-MSCs (3v3):', size=8.8, ha='left')
txt(RX + 47.6, 47.0, '0 BH-significant genes', size=8.8, ha='right', color='#555555')
txt(RX + 2.4, 43.6, 'Senescence module not elevated in OA donors (P = 0.057)', size=8.4, ha='left', color='#555555')
txt(RX + 2.4, 40.0, 'GSE239343  ASC secretome vs TNF-inflamed chondrocytes:', size=8.8, ha='left')
txt(RX + 47.6, 40.0, '555 up / 557 down', size=8.8, ha='right', color='#555555')
txt(RX + 2.4, 36.6, '98% of TNF-induced genes return ≥50% to baseline (empirical P = 0.047)', size=8.4,
    ha='left', color='#555555')

# ================= RIGHT LOWER: niche card =================
card(RX, 12, 50, 19.5, '#edf3ea', ec='#1b7837', lw=1.4)
txt(RX + 25, 29.0, 'Layer 3 — The target niche', size=11, weight='bold', color=PALETTE['third'])
txt(RX + 2.4, 25.0, 'GSE248453  22,113 cells, 8 patients (high vs low pain):', size=8.8, ha='left')
txt(RX + 47.6, 25.0, 'fibroblasts +26.6 pp, CI 15.3–38.6', size=8.6, ha='right', color='#555555')
txt(RX + 2.4, 21.6, 'exact PERMANOVA P = 0.057 · 6/9 robustness settings P = 0.029', size=8.4,
    ha='left', color='#555555')
txt(RX + 2.4, 18.0, 'GSE216651  replication, 93,105 cells, 4 healthy vs 5 OA donors:', size=8.8, ha='left')
txt(RX + 47.6, 18.0, 'composition preserved (P = 0.66)', size=8.6, ha='right', color='#555555')
txt(RX + 2.4, 14.6, 'MSC-like DKK1/CXCL12+ fibroblasts double in OA (P = 0.063)', size=8.4,
    ha='left', color='#555555')

# ================= BOTTOM: integration band =================
card(RX, 2.0, 50, 8.5, '#fffbe8', ec='#e67e22', lw=1.5)
txt(RX + 25, 8.4, 'Integration: premises confronted with measured biology', size=10, weight='bold')
txt(RX + 25, 4.6, 'dose unmeasured ↔ rescue depth real   ·   autologous ↔ no cell-intrinsic barrier\n'
                  'niche varies with pain ↔ stratify enrolment   ·   5.3% reporting ↔ reported effects mixed',
    size=8.2, ls=1.6)

# connectors from cards to integration band
for yy in (34, 12):
    ax.add_patch(FancyArrowPatch((75, yy - 0.6), (75, 10.9), arrowstyle='-|>',
                                 mutation_scale=12, lw=1.4, color='#e67e22'))

fig.savefig(os.path.join(FIG, 'Fig1_workflow_mpl.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig1_workflow.pdf'), dpi=920)
plt.close(fig)
print('Fig1 rebuilt')
