# -*- coding: utf-8 -*-
"""GSE248453 scRNA pipeline: waits for tar completion, extracts, runs scanpy QC →
clustering → annotation → pain-stratified analyses. Saves h5ad + metrics JSON + CSVs."""
import os, sys, io, json, time, tarfile, glob, shutil
import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(BASE, 'data', 'geo')
EX = os.path.join(D, 'GSE248453_extract')
OUT = os.path.join(BASE, 'results', 'scrna')
os.makedirs(OUT, exist_ok=True)
LOGP = os.path.join(BASE, 'data', 'scrna_pipeline.log')

def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)
    io.open(LOGP, 'a', encoding='utf-8').write(s + '\n')

def filled_frac(p, probe=1 << 22):
    size = os.path.getsize(p)
    with open(p, 'rb') as f:
        f.seek(max(0, size - probe))
        return any(f.read(probe))

# ---------- 1. wait for tar ----------
tar_path = os.path.join(D, 'GSE248453_RAW.tar')
while True:
    import numpy as np
    size = os.path.getsize(tar_path)
    mm = np.memmap(tar_path, dtype=np.uint8, mode='r')
    BLK = 1 << 20
    nb = size // BLK
    filled = 0
    for i in range(nb):
        if mm[i * BLK:(i + 1) * BLK:4096].any():
            filled += 1
    del mm
    frac = filled / max(nb, 1)
    log('tar fill: %.1f%%' % (100 * frac))
    if frac > 0.995:
        break
    time.sleep(240)

# ---------- 2. extract ----------
if not os.path.exists(EX):
    os.makedirs(EX, exist_ok=True)
    with tarfile.open(tar_path) as tf:
        tf.extractall(EX, filter='data')
log('extracted:', len(os.listdir(EX)))

# ---------- 3. load ----------
import scanpy as sc
import anndata as ad
import scipy.io
from scipy import sparse as sp
sc.settings.verbosity = 1

# flat archive: files named GSM..._DK#_{low,high}_{matrix.mtx,barcodes.tsv,features.tsv}.gz
files = sorted(os.listdir(EX))
prefixes = sorted(set(f.rsplit('_', 1)[0].rsplit('_', 1)[0].rsplit('_', 1)[0] for f in files
                      if f.endswith('_matrix.mtx.gz')))
# more robust: strip known suffixes
prefixes = sorted(set(f[:-len('_matrix.mtx.gz')] for f in files if f.endswith('_matrix.mtx.gz')))
log('sample prefixes:', prefixes)

adatas = []
for pref in prefixes:
    mtx = os.path.join(EX, pref + '_matrix.mtx.gz')
    bcs = os.path.join(EX, pref + '_barcodes.tsv.gz')
    feats = os.path.join(EX, pref + '_features.tsv.gz')
    M = scipy.io.mmread(mtx)
    M = sp.csr_matrix(M)
    bc = [ln.strip() for ln in __import__('gzip').open(bcs, 'rt').read().splitlines() if ln.strip()]
    feat_tab = pd.read_csv(feats, sep='\t', header=None, dtype=str)
    feats_names = feat_tab[1].tolist() if feat_tab.shape[1] > 1 else feat_tab[0].tolist()
    if M.shape[1] == len(bc) and M.shape[0] != len(bc):
        M = M.T  # 10X mtx is genes x cells -> cells x genes
    if M.shape[0] != len(bc):
        log('shape mismatch', pref, M.shape, len(bc))
        continue
    a = ad.AnnData(X=M, obs=pd.DataFrame(index=[b + '-' + pref for b in bc]),
                   var=pd.DataFrame(index=pd.Index(feats_names, name='gene')))
    a.var_names_make_unique()
    tag = pref.split('_', 1)[1] if '_' in pref else pref
    a.obs['sample'] = tag
    adatas.append(a)
    log('loaded', tag, a.shape)

pain_map = {}
for k in set(a.obs['sample'].iloc[0] for a in adatas):
    pain_map[k] = 'high pain' if 'high' in k.lower() else ('low pain' if 'low' in k.lower() else 'unknown')

adata = ad.concat(adatas, label='sample_id', keys=[a.obs['sample'].iloc[0] for a in adatas], index_unique='-')
adata.obs['pain'] = adata.obs['sample'].map(pain_map)
log('concat:', adata.shape)

# ---------- 4. QC ----------
adata.var['mt'] = adata.var_names.str.startswith('MT-')
sc.pp.calculate_qc_metrics(adata, qc_vars=['mt'], percent_top=None, log1p=False, inplace=True)
n0 = adata.n_obs
adata = adata[adata.obs['n_genes_by_counts'] >= 200, :]
adata = adata[adata.obs['n_genes_by_counts'] <= 6000, :]
adata = adata[adata.obs['pct_counts_mt'] <= 20, :]
log('QC: %d -> %d cells' % (n0, adata.n_obs))
CACHE = os.path.join(OUT, 'cache_annotated.h5ad')
if os.path.exists(CACHE) and os.environ.get('SCRNA_FORCE', '') != '1':
    adata = sc.read_h5ad(CACHE)
    log('loaded annotated cache', adata.shape)
    SKIP_MAIN = True
else:
    SKIP_MAIN = False

# ---------- 5. normalize/embed ----------
if not SKIP_MAIN:
    adata.layers['counts'] = adata.X.copy()
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    sc.pp.highly_variable_genes(adata, n_top_genes=3000, batch_key='sample', subset=False)
    adata.raw = adata
    sc.pp.scale(adata, max_value=10)
    sc.tl.pca(adata, n_comps=50, svd_solver='arpack', use_highly_variable=True)
    sc.pp.neighbors(adata, n_neighbors=15, n_pcs=30)
    sc.tl.leiden(adata, resolution=1.0, key_added='leiden', flavor='igraph', n_iterations=2, directed=False)
    sc.tl.umap(adata)
    log('clustered:', adata.obs['leiden'].value_counts().to_dict())

    # ---------- 6. annotate ----------
    MARKERS = {
        'macrophage/monocyte': ['LYZ', 'CD68', 'C1QA', 'C1QB', 'CD14', 'FCGR3A', 'MSR1'],
        'T/NK cell': ['CD3D', 'CD3E', 'TRAC', 'NKG7', 'GNLY', 'CD8A'],
        'B/plasma cell': ['MS4A1', 'CD79A', 'MZB1', 'JCHAIN'],
        'mast cell': ['KIT', 'CPA3', 'TPSAB1'],
        'endothelial cell': ['PECAM1', 'VWF', 'CLDN5', 'CDH5'],
        'pericyte/SMC': ['RGS5', 'ACTA2', 'TAGLN', 'MYH11'],
        'fibroblast/MSC-lineage': ['DCN', 'LUM', 'THY1', 'COL1A1', 'PI16'],
        'adipocyte': ['ADIPOQ', 'PLIN1', 'LPL'],
        'chondrocyte-like': ['COL2A1', 'ACAN', 'CHAD', 'HAPLN1'],
    }
    scores = pd.DataFrame(index=adata.obs_names)
    for k, genes in MARKERS.items():
        genes_ok = [g for g in genes if g in adata.raw.var_names]
        sc.tl.score_genes(adata, gene_list=genes_ok, score_name='sc_' + k.replace('/', '_'), use_raw=True)
        scores['sc_' + k.replace('/', '_')] = adata.obs['sc_' + k.replace('/', '_')].values
    score_cols = ['sc_' + k.replace('/', '_') for k in MARKERS]
    best = scores[score_cols].idxmax(axis=1).str.replace('sc_', '').str.replace('_', '/')
    bestv = scores[score_cols].max(axis=1)
    annot = best.where((bestv > 0.2), 'unannotated')
    vote = pd.crosstab(adata.obs['leiden'], annot)
    cluster_annot = vote.idxmax(axis=1)
    adata.obs['cell_type'] = adata.obs['leiden'].map(cluster_annot)
    log('cell types:', adata.obs['cell_type'].value_counts().to_dict())
    adata.write(CACHE)

# ---------- 7. fibro/MSC subclustering ----------
fib = adata[adata.obs['cell_type'] == 'fibroblast/MSC-lineage'].copy()
sc.pp.highly_variable_genes(fib, n_top_genes=2000)
# drop zero-variance genes that produce NaN during scaling
var_ok = fib.var['highly_variable'].fillna(False).values
fib = fib[:, var_ok].copy()
sc.pp.scale(fib, max_value=10)
sc.tl.pca(fib, n_comps=25, svd_solver='arpack')
sc.pp.neighbors(fib, n_neighbors=15, n_pcs=20)
sc.tl.leiden(fib, resolution=0.8, key_added='fleiden', flavor='igraph', n_iterations=2, directed=False)
sc.tl.umap(fib)
FIB_MARKS = {
    'lining CD55+': ['CD55', 'PI16', 'SFRP2', 'SFRP4'],
    'sublining THY1+': ['THY1', 'CFD', 'RGS1', 'IL6'],
    'MSC-like DKK1/CXCL12+': ['DKK1', 'CXCL12', 'LEPR', 'NT5E'],
    'CD34+ progenitor': ['CD34', 'KDR'],
    'myofibroblast': ['ACTA2', 'MYH10', 'TAGLN'],
}
for k, genes in FIB_MARKS.items():
    genes_ok = [g for g in genes if g in fib.raw.var_names]
    if genes_ok:
        sc.tl.score_genes(fib, gene_list=genes_ok, score_name='f_' + k)
fcols = ['f_' + k for k in FIB_MARKS]
fs = pd.DataFrame(fib.obs[fcols].values, columns=fcols, index=fib.obs_names)
fbest = fs.idxmax(axis=1).str.replace('f_', '')
fbestv = fs.max(axis=1)
fib.obs['fib_subtype'] = fbest.where(fbestv > 0.2, 'unclassified').values
log('fib subtypes:', fib.obs['fib_subtype'].value_counts().to_dict())
adata.obs['fib_subtype'] = ['-'] * adata.n_obs
common_cells = adata.obs_names.intersection(fib.obs_names)
adata.obs.loc[common_cells, 'fib_subtype'] = fib.obs.loc[common_cells, 'fib_subtype'].values

# ---------- 8. differential abundance (donor-level) ----------
from scipy import stats as sps
samples = sorted(adata.obs['sample'].unique())
prop = {}
for ct in adata.obs['cell_type'].value_counts().index:
    row = {}
    for s in samples:
        sub = adata.obs[adata.obs['sample'] == s]
        row[s] = 100.0 * (sub['cell_type'] == ct).mean()
    prop[ct] = row
prop = pd.DataFrame(prop).T
pain_of = {s: pain_map[s] for s in samples}
low_s = [s for s in samples if pain_of[s] == 'low pain']
high_s = [s for s in samples if pain_of[s] == 'high pain']
da_rows = []
for ct in prop.index:
    a_ = prop.loc[ct, high_s].values.astype(float)
    b_ = prop.loc[ct, low_s].values.astype(float)
    u, pv = sps.mannwhitneyu(a_, b_, alternative='two-sided')
    l2 = np.log2((a_.mean() + 0.1) / (b_.mean() + 0.1))
    da_rows.append({'cell_type': ct, 'mean_high': a_.mean(), 'mean_low': b_.mean(),
                    'log2FC_high_vs_low': l2, 'MWU_p': pv})
da = pd.DataFrame(da_rows).sort_values('MWU_p')
da.to_csv(os.path.join(OUT, 'diff_abundance.csv'), index=False)

# ---------- 9. senescence/SASP modules ----------
MODS = {
    'senescence_core': ['CDKN1A', 'CDKN2A', 'CDKN2B', 'SERPINE1', 'GLB1', 'GADD45A', 'GADD45B', 'MDM2', 'BAX', 'PMAIP1'],
    'sasp': ['IL6', 'CXCL8', 'CCL2', 'CCL20', 'CXCL1', 'CXCL2', 'CXCL3', 'IL1B', 'MMP1', 'MMP3',
             'MMP10', 'MMP13', 'MMP14', 'TIMP1', 'TIMP2', 'IGFBP3', 'IGFBP4', 'IGFBP5', 'PLAU', 'PLAUR',
             'VCAM1', 'ICAM1', 'PTGS2'],
}
Xraw = adata.raw.X
gidx = {g: i for i, g in enumerate(adata.raw.var_names)}
mu = np.asarray(Xraw.mean(axis=0)).ravel()
mu2 = np.asarray(Xraw.power(2).mean(axis=0)).ravel() if sp.issparse(Xraw) else np.asarray((Xraw ** 2).mean(axis=0)).ravel()
sd = np.sqrt(np.clip(mu2 - mu ** 2, 0, None))
sd[sd == 0] = 1
from scipy import sparse
for m, genes in MODS.items():
    gsel = [gidx[g] for g in genes if g in gidx]
    Z = Xraw[:, gsel]
    Z = (Z - mu[gsel]) / sd[gsel]
    adata.obs['mod_' + m] = np.asarray(Z.mean(axis=1)).ravel() if sp.issparse(Z) else Z.mean(axis=1)

mod_rows = []
for ct in adata.obs['cell_type'].value_counts().index:
    for m in MODS:
        row = {'cell_type': ct, 'module': m}
        for cond, ss in [('high', high_s), ('low', low_s)]:
            mask = adata.obs['sample'].isin(ss) & (adata.obs['cell_type'] == ct)
            row['mean_' + cond] = float(adata.obs.loc[mask, 'mod_' + m].mean())
        row['delta_high_minus_low'] = row['mean_high'] - row['mean_low']
        mod_rows.append(row)
mod_df = pd.DataFrame(mod_rows)
mod_df.to_csv(os.path.join(OUT, 'module_by_type_pain.csv'), index=False)

# donor-level module comparison within fibroblast/MSC and macrophage
donor_mod = []
for ct in ['fibroblast/MSC-lineage', 'macrophage/monocyte']:
    for m in MODS:
        vals = {}
        for s in samples:
            mask = (adata.obs['sample'] == s) & (adata.obs['cell_type'] == ct)
            vals[s] = float(adata.obs.loc[mask, 'mod_' + m].mean()) if mask.sum() >= 10 else np.nan
        a_ = np.array([vals[s] for s in high_s], dtype=float)
        b_ = np.array([vals[s] for s in low_s], dtype=float)
        u, pv = sps.mannwhitneyu(a_[~np.isnan(a_)], b_[~np.isnan(b_)], alternative='two-sided')
        donor_mod.append({'cell_type': ct, 'module': m,
                          'mean_high': float(np.nanmean(a_)), 'mean_low': float(np.nanmean(b_)), 'MWU_p': pv})
pd.DataFrame(donor_mod).to_csv(os.path.join(OUT, 'module_donor_stats.csv'), index=False)

# ---------- 10. ligand-receptor ----------
PAIRS = [
    ('SPP1', 'CD44'), ('SPP1', 'ITGAV'), ('CCL2', 'CCR2'), ('CCL3', 'CCR1'), ('CXCL12', 'CXCR4'),
    ('VEGFA', 'KDR'), ('VEGFA', 'FLT1'), ('IL6', 'IL6R'), ('LIF', 'LIFR'), ('APOE', 'TREM2'),
    ('APOE', 'LRP1'), ('THBS1', 'CD47'), ('GAS6', 'AXL'), ('CXCL2', 'CXCR2'), ('CCL5', 'CCR5'),
    ('TGFB1', 'TGFBR1'), ('PDGFB', 'PDGFRB'), ('ANXA1', 'FPR1'),
]
def mean_pct(expr_sub, gene):
    if gene not in gidx:
        return 0.0, 0.0
    v = expr_sub[:, gidx[gene]]
    v = np.asarray(v.todense()).ravel() if sp.issparse(v) else np.asarray(v).ravel()
    return float(v.mean()), float((v > 0).mean())

comps = {
    'macrophage': (adata.obs['cell_type'] == 'macrophage/monocyte').values,
    'fibro_MSC': (adata.obs['cell_type'] == 'fibroblast/MSC-lineage').values,
    'endothelial': (adata.obs['cell_type'] == 'endothelial cell').values,
    'pericyte_SMC': (adata.obs['cell_type'] == 'pericyte/SMC').values,
    'TNK': (adata.obs['cell_type'] == 'T/NK cell').values,
}
lr_rows = []
for lig, rec in PAIRS:
    row = {'ligand': lig, 'receptor': rec}
    for cname, mask in comps.items():
        lm, lp = mean_pct(Xraw[mask], lig)
        rm, rp = mean_pct(Xraw[mask], rec)
        row[cname + '_L'] = lm
        row[cname + '_Lpct'] = lp
        row[cname + '_R'] = rm
        row[cname + '_Rpct'] = rp
    row['score_macro_fib'] = row['macrophage_L'] * row['fibro_MSC_R']
    row['score_fib_macro'] = row['fibro_MSC_L'] * row['macrophage_R']
    lr_rows.append(row)
pd.DataFrame(lr_rows).to_csv(os.path.join(OUT, 'ligand_receptor.csv'), index=False)

# ---------- 11. save ----------
adata.write(os.path.join(OUT, 'GSE248453_processed.h5ad'), compression='gzip')
metrics = {
    'n_cells': int(adata.n_obs), 'n_genes': int(adata.n_vars),
    'samples': {s: pain_map[s] for s in samples},
    'cells_per_sample': adata.obs['sample'].value_counts().to_dict(),
    'cell_types': adata.obs['cell_type'].value_counts().to_dict(),
    'fib_subtypes': fib.obs['fib_subtype'].value_counts().to_dict(),
}
io.open(os.path.join(OUT, 'scrna_metrics.json'), 'w', encoding='utf-8').write(json.dumps(metrics, indent=1, default=str))
prop.to_csv(os.path.join(OUT, 'per_sample_proportions.csv'))
log('PIPELINE DONE')
