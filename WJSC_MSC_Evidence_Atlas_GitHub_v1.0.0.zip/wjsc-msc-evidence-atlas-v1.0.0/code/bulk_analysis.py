# -*- coding: utf-8 -*-
"""Bulk transcriptomic reanalysis of GSE239343 (ASC secretome rescue) and
GSE267908 (OA-donor vs non-OA-donor BM-MSCs). All inputs are GEO series matrices
plus published probe annotations. Results saved to results/bulk/ + analysis_log.json."""
import io, os, json, hashlib, time
import numpy as np
import pandas as pd
from scipy import stats

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, 'data')
OUT = os.path.join(BASE, 'results', 'bulk')
os.makedirs(OUT, exist_ok=True)
LOGJ = {}

def log(*a):
    s = ' '.join(str(x) for x in a)
    print(s, flush=True)

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

MODULES = {
    'senescence_core': ['CDKN1A', 'CDKN2A', 'CDKN2B', 'SERPINE1', 'GLB1', 'GADD45A',
                        'GADD45B', 'MDM2', 'BAX', 'PMAIP1'],
    'sasp': ['IL6', 'CXCL8', 'CCL2', 'CCL20', 'CXCL1', 'CXCL2', 'CXCL3', 'IL1B', 'IL1A',
             'MMP1', 'MMP3', 'MMP10', 'MMP13', 'MMP14', 'TIMP1', 'TIMP2', 'IGFBP3',
             'IGFBP4', 'IGFBP5', 'PLAU', 'PLAUR', 'VCAM1', 'ICAM1', 'PTGS2', 'NFKB1', 'RELA'],
    'chondrogenic': ['SOX9', 'COL2A1', 'ACAN', 'COL11A1', 'COMP', 'PRG4', 'CHAD',
                     'HAPLN1', 'SOX5', 'SOX6', 'COL9A1', 'CRTL1'],
    'catabolic': ['MMP13', 'MMP3', 'MMP1', 'ADAMTS4', 'ADAMTS5', 'ADAMTS1', 'ADAMTS9',
                  'NOS2', 'IL1B', 'PTGS2'],
    'osteoogenic': ['RUNX2', 'ALPL', 'BGLAP', 'COL1A1', 'COL1A2', 'SP7', 'IBSP', 'SPP1', 'POSTN'],
    'immunomodulatory': ['IDO1', 'TGFB1', 'IL10', 'PTGS2', 'HMOX1', 'TGFBR1', 'SOCS1',
                         'SOCS3', 'TNFAIP6', 'PTGES'],
    'trophic_paracrine': ['VEGFA', 'HGF', 'ANGPT1', 'FGF2', 'IGF1', 'PDGFA', 'BDNF', 'EGF'],
    'proliferation': ['MKI67', 'TOP2A', 'PCNA', 'MCM2', 'MCM4', 'MCM6', 'CCND1', 'CCNB1',
                      'CDK4', 'BIRC5'],
    'apoptotic_stress': ['BAX', 'BCL2', 'CASP3', 'CASP8', 'BBC3', 'PMAIP1', 'DDIT3', 'ATF4'],
}

def parse_series_matrix(path):
    """Return (expr DataFrame geneidx, samples list of dicts with title/gsm/group order)."""
    met = {}
    table = []
    in_table = False
    header = None
    for line in io.open(path, encoding='utf-8'):
        line = line.rstrip('\n')
        if line.startswith('!series_matrix_table_begin'):
            in_table = True; continue
        if line.startswith('!series_matrix_table_end'):
            break
        if in_table:
            if header is None:
                header = [c.strip('"') for c in line.split('\t')]
                continue
            table.append([c.strip('"') for c in line.split('\t')])
            continue
        if line.startswith('!'):
            key = line.split('\t')[0]
            val = [c.strip('"') for c in line.split('\t')[1:]]
            met.setdefault(key, val)
    samples = met.get('!Sample_title', [])
    gsms = met.get('!Sample_geo_accession', [])
    chars = met.get('!Sample_characteristics_ch1', [])
    expr = pd.DataFrame(table, columns=header).set_index('ID_REF')
    for c in expr.columns:
        expr[c] = pd.to_numeric(expr[c], errors='coerce')
    return expr, samples, gsms, chars

def collapse_to_genes(expr, probe2sym):
    sym = expr.index.map(lambda p: probe2sym.get(p, None))
    e = expr.copy()
    e['symbol'] = sym
    e = e[e['symbol'].notna() & (e['symbol'] != '')]
    gene_expr = e.groupby('symbol').mean(numeric_only=True)
    return gene_expr

def welch_bh(expr, g1_samples, g2_samples):
    x1 = expr[g1_samples].values
    x2 = expr[g2_samples].values
    t, p = stats.ttest_ind(x1, x2, axis=1, equal_var=False)
    l2 = np.log2((x1.mean(1) + 1) / (x2.mean(1) + 1))
    order = np.argsort(p)
    n = len(p)
    ranks = np.empty(n)
    ranks[order] = np.arange(1, n + 1)
    q = np.minimum(1, p * n / ranks)
    # enforce BH monotonicity
    qs = q[order]
    qs = np.minimum.accumulate(qs[::-1])[::-1]
    q[order] = qs
    return pd.DataFrame({'t': t, 'p': p, 'log2FC': l2, 'BH_q': q},
                        index=expr.index)

def module_scores(expr, modules):
    mu = expr.mean(axis=1)
    sd = expr.std(axis=1).replace(0, np.nan)
    z = expr.sub(mu, axis=0).div(sd, axis=0)
    rows = {}
    detail = {}
    for m, genes in modules.items():
        present = [g for g in genes if g in z.index]
        if not present:
            rows[m] = None; detail[m] = []
            continue
        rows[m] = z.loc[present].mean(axis=0)
        detail[m] = present
    return pd.DataFrame(rows), detail

def fmt3(x):
    return float('%.3g' % x)

# ================= GSE239343 =================
log('=== GSE239343 (ASC secretome rescue, GPL10558) ===')
sm = os.path.join(DATA, 'geo_sm', 'GSE239343_series_matrix.txt')
expr, titles, gsms, chars = parse_series_matrix(sm)
groups = {}
for gsm, t in zip(gsms, titles):
    t = t.strip()
    if t.startswith('Cond_'):
        groups[gsm] = 'Chondrocytes'
    elif t.startswith('AT_MSC'):
        groups[gsm] = 'ASC'
    elif t.startswith('CON_TNF_Med'):
        groups[gsm] = 'TNF+ASC-CM'
    elif t.startswith('CON_TNF'):
        groups[gsm] = 'TNF'
log('groups:', {k: sum(1 for v in groups.values() if v == k) for k in set(groups.values())})

p2s = {}
for ln in io.open(os.path.join(DATA, 'GPL10558_probe2symbol.tsv'), encoding='utf-8').read().splitlines()[1:]:
    a, b = ln.split('\t')
    p2s[a] = b
ge = collapse_to_genes(expr, p2s)
log('genes after collapse:', ge.shape)

samples_by = {g: [gsm for gsm, gg in groups.items() if gg == g] for g in set(groups.values())}
ge_log = ge  # Illumina HumanHT-12 series-matrix values are already log2-transformed

deg_infl = welch_bh(ge_log, samples_by['TNF'], samples_by['Chondrocytes'])
deg_resc = welch_bh(ge_log, samples_by['TNF+ASC-CM'], samples_by['TNF'])
deg_infl.sort_values('p').to_csv(os.path.join(OUT, 'GSE239343_TNF_vs_Chondrocytes.csv'))
deg_resc.sort_values('p').to_csv(os.path.join(OUT, 'GSE239343_ASCCM_vs_TNF.csv'))

# rescue fraction (significance = BH_q < 0.05; the Illumina series-matrix values are
# variance-compressed so no fold-change cutoff is applied)
sig_up = deg_infl[(deg_infl['BH_q'] < 0.05) & (deg_infl['log2FC'] > 0)]
sig_dn = deg_infl[(deg_infl['BH_q'] < 0.05) & (deg_infl['log2FC'] < 0)]
common = deg_infl.index.intersection(deg_resc.index)
ret = pd.DataFrame({
    'l2_TNF_vs_Cond': deg_infl.loc[common, 'log2FC'],
    'l2_CM_vs_TNF': deg_resc.loc[common, 'log2FC']})
ret['return_frac'] = (ret['l2_TNF_vs_Cond'] - ret['l2_CM_vs_TNF']) / ret['l2_TNF_vs_Cond']
rescued_up = ret.loc[sig_up.index.intersection(common)]
rescued_dn = ret.loc[sig_dn.index.intersection(common)]
frac_up_rescued = float((rescued_up['return_frac'] >= 0.5).mean())
frac_up_reversed = float((rescued_up['return_frac'] > 0).mean())
frac_dn_rescued = float((rescued_dn['return_frac'] >= 0.5).mean())
frac_dn_reversed = float((rescued_dn['return_frac'] > 0).mean())

# vector correlation
common2 = deg_infl.index.intersection(deg_resc.index)
r_vec, p_vec = stats.spearmanr(deg_infl.loc[common2, 'log2FC'], deg_resc.loc[common2, 'log2FC'])

ms, detail = module_scores(ge_log, MODULES)
ms.to_csv(os.path.join(OUT, 'GSE239343_module_scores.csv'))
mod_grp = ms.copy()
mod_grp['group'] = [groups[g] for g in ms.index]

LOGJ['GSE239343'] = {
    'n_samples': len(gsms) - 1,
    'groups': {k: len(v) for k, v in samples_by.items()},
    'genes': int(ge.shape[0]),
    'TNF_vs_Cond_sig_up': int(len(sig_up)), 'TNF_vs_Cond_sig_dn': int(len(sig_dn)),
    'rescue_up_ge50pct': frac_up_rescued, 'rescue_up_any_reversal': frac_up_reversed,
    'rescue_dn_ge50pct': frac_dn_rescued, 'rescue_dn_any_reversal': frac_dn_reversed,
    'rescue_vector_spearman_r': fmt3(r_vec), 'rescue_vector_spearman_p': fmt3(p_vec),
    'module_genes_used': detail,
    'series_matrix_sha256': sha256(sm),
}

# ================= GSE267908 =================
log('=== GSE267908 (OA-donor vs non-OA-donor BM-MSC, GPL570) ===')
sm2 = os.path.join(DATA, 'geo_sm', 'GSE267908_series_matrix.txt')
expr2, titles2, gsms2, chars2 = parse_series_matrix(sm2)
groups2 = {}
for gsm, t in zip(gsms2, titles2):
    t = t.strip()
    if 'OA_rep' in t:
        groups2[gsm] = 'OA-donor MSC'
    elif 'ND_rep' in t:
        groups2[gsm] = 'non-OA-donor MSC'
log('groups2:', groups2)

p2s2_path = os.path.join(DATA, 'GPL570_probe2symbol.tsv')
if os.path.exists(p2s2_path) and os.path.getsize(p2s2_path) > 10000:
    p2s2 = {}
    for ln in io.open(p2s2_path, encoding='utf-8').read().splitlines()[1:]:
        a, b = ln.split('\t')
        p2s2[a] = b
    ge2 = collapse_to_genes(expr2, p2s2)
    samples_by2 = {g: [gsm for gsm, gg in groups2.items() if gg == g] for g in set(groups2.values())}
    ge2_log = np.log2(ge2 + 1)
    deg_donor = welch_bh(ge2_log, samples_by2['OA-donor MSC'], samples_by2['non-OA-donor MSC'])
    deg_donor.sort_values('p').to_csv(os.path.join(OUT, 'GSE267908_OAvsND_MSC.csv'))
    ms2, detail2 = module_scores(ge2_log, MODULES)
    ms2.to_csv(os.path.join(OUT, 'GSE267908_module_scores.csv'))
    sig_up2 = deg_donor[(deg_donor['BH_q'] < 0.05) & (deg_donor['log2FC'] > 0)]
    sig_dn2 = deg_donor[(deg_donor['BH_q'] < 0.05) & (deg_donor['log2FC'] < 0)]
    LOGJ['GSE267908'] = {
        'n_samples': len(gsms2) - 1,
        'groups': {k: len(v) for k, v in samples_by2.items()},
        'genes': int(ge2.shape[0]),
        'sig_up_q05': int(len(sig_up2)), 'sig_dn_q05': int(len(sig_dn2)),
        'module_genes_used': detail2,
        'series_matrix_sha256': sha256(sm2),
    }
    ms2.to_csv(os.path.join(OUT, 'GSE267908_module_scores.csv'))
else:
    LOGJ['GSE267908'] = {'status': 'probe map not ready'}

LOGJ['_modules'] = MODULES
io.open(os.path.join(BASE, 'results', 'bulk_analysis_log.json'), 'w', encoding='utf-8').write(
    json.dumps(LOGJ, indent=1, ensure_ascii=False))
log('saved results/bulk_analysis_log.json')

# print key numbers
if 'GSE239343' in LOGJ:
    j = LOGJ['GSE239343']
    print('GSE239343: TNF-up DEGs:', j['TNF_vs_Cond_sig_up'], '| TNF-down:', j['TNF_vs_Cond_sig_dn'])
    print('  rescue >=50%% of TNF-up genes: %.2f | any reversal: %.2f' % (j['rescue_up_ge50pct'], j['rescue_up_any_reversal']))
    print('  rescue >=50%% of TNF-down genes: %.2f | any reversal: %.2f' % (j['rescue_dn_ge50pct'], j['rescue_dn_any_reversal']))
    print('  vector spearman r=%.3g p=%.3g' % (j['rescue_vector_spearman_r'], j['rescue_vector_spearman_p']))
if 'genes' in LOGJ.get('GSE267908', {}):
    j2 = LOGJ['GSE267908']
    print('GSE267908: genes:', j2['genes'], '| sig up (BH<0.05):', j2['sig_up_q05'], '| down:', j2['sig_dn_q05'])
