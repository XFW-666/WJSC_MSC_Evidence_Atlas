# -*- coding: utf-8 -*-
"""Fig 6 (single-cell atlas), Fig 7 (pain-stratified mechanism), Fig 9 (integration)."""
import io, os, json
import pandas as pd
import numpy as np
from scipy import stats as sps
import scanpy as sc
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch
from figstyle import (plt, PALETTE, despine, panel_label)

BASE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.join(BASE, 'results', 'scrna')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)

adata = sc.read_h5ad(os.path.join(SCR, 'GSE248453_processed.h5ad'))
da = pd.read_csv(os.path.join(SCR, 'diff_abundance.csv'))
modp = pd.read_csv(os.path.join(SCR, 'module_by_type_pain.csv'))
moddon = pd.read_csv(os.path.join(SCR, 'module_donor_stats.csv'))
lr = pd.read_csv(os.path.join(SCR, 'ligand_receptor.csv'))
metrics = json.loads(io.open(os.path.join(SCR, 'scrna_metrics.json'), encoding='utf-8').read())

CT_COLORS = {
    'macrophage/monocyte': '#b2182b', 'chondrocyte-like': '#e08214',
    'fibroblast/MSC-lineage': '#2166ac', 'B/plasma cell': '#762a83',
    'T/NK cell': '#1b7837', 'endothelial cell': '#c51b7b',
    'pericyte/SMC': '#01665e', 'mast cell': '#54278f', 'unannotated': '#bbbbbb',
}
FIB_COLORS = {
    'lining CD55+': '#2166ac', 'sublining THY1+': '#b2182b',
    'MSC-like DKK1/CXCL12+': '#1b7837', 'CD34+ progenitor': '#e08214',
    'myofibroblast': '#762a83', 'unclassified': '#bbbbbb',
}

# ================= FIG 6 =================
fig = plt.figure(figsize=(12, 17.2))
gs = fig.add_gridspec(4, 2, hspace=0.46, wspace=0.26, left=0.11, right=0.96, top=0.955, bottom=0.04)

from matplotlib.colors import LinearSegmentedColormap
for i, (col, palette, title, lab) in enumerate([
        ('cell_type', CT_COLORS, 'Cell-type density (hex)', 'A'),
        ('pain', {'high pain': '#b2182b', 'low pain': '#2166ac'}, 'Pain-stratum density (hex)', 'B')]):
    ax = fig.add_subplot(gs[0, i])
    pts = adata.obsm['X_umap']
    cmap = LinearSegmentedColormap.from_list('den', ['#f2f2f2', '#7aaed6', '#1f4e79'])
    hb = ax.hexbin(pts[:, 0], pts[:, 1], gridsize=95, cmap=cmap, mincnt=1,
                   linewidths=0.05, edgecolors='#dddddd')
    plt.colorbar(hb, ax=ax, fraction=0.045, pad=0.02, label='cells per hexagon')
    cats = adata.obs[col].astype(str)
    for c in sorted(cats.unique(), key=lambda c: -((cats == c).sum())):
        m = (cats == c).values
        if m.sum() < 400:
            continue
        cx, cy = pts[m, 0].mean(), pts[m, 1].mean()
        SHORTL = {'macrophage/monocyte': 'Macrophage', 'fibroblast/MSC-lineage': 'Fibroblast/MSC',
                  'high pain': 'High pain', 'low pain': 'Low pain'}
        ax.text(cx, cy, SHORTL.get(c, c), fontsize=8.6, ha='center', va='center',
                fontweight='bold', color='white',
                bbox=dict(boxstyle='round,pad=0.3', fc='#222222', ec='none', alpha=0.85))
    ax.set_xticks([]); ax.set_yticks([])
    for sp_ in ax.spines.values():
        sp_.set_visible(False)
    ax.set_title(title, loc='left', fontsize=10.5)
    panel_label(ax, lab, dx=0.0, dy=1.04)

# (C) split violin of donor-level shares per type (low vs high pain)
ax = fig.add_subplot(gs[1, 0])
propd = pd.read_csv(os.path.join(SCR, 'per_sample_proportions.csv'), index_col=0)
samples_v = list(propd.columns)
pain_of_v = {s: metrics['samples'][s] for s in samples_v}
types_v = [t2 for t2 in propd.index if t2 != 'unannotated']
types_v = sorted(types_v, key=lambda t2: -(propd.loc[t2].mean()))
parts = ax.violinplot([np.array([max(propd.loc[t2, s], 0.05) for s in samples_v if pain_of_v[s] == 'low pain'])
                       for t2 in types_v], positions=np.arange(len(types_v)) - 0.18,
                      widths=0.32, showextrema=False, side='low')
for pc in parts['bodies']:
    pc.set_facecolor('#2166ac'); pc.set_alpha(0.75); pc.set_edgecolor('none')
parts2 = ax.violinplot([np.array([max(propd.loc[t2, s], 0.05) for s in samples_v if pain_of_v[s] == 'high pain'])
                        for t2 in types_v], positions=np.arange(len(types_v)) + 0.18,
                       widths=0.32, showextrema=False, side='high')
for pc in parts2['bodies']:
    pc.set_facecolor('#b2182b'); pc.set_alpha(0.75); pc.set_edgecolor('none')
for yi, t2 in enumerate(types_v):
    for grp, colr, off in [('low pain', '#2166ac', -0.18), ('high pain', '#b2182b', 0.18)]:
        vals = np.array([max(propd.loc[t2, s], 0.05) for s in samples_v if pain_of_v[s] == grp])
        ax.scatter(np.full(len(vals), yi + off), vals, s=14, color=colr, alpha=0.9,
                   edgecolors='white', linewidths=0.4, zorder=4)
ax.set_yscale('log')
ax.set_xlim(-0.7, len(types_v) - 0.3)
ax.set_yticks([0.1, 1, 10, 100])
ax.set_yticklabels(['0.1', '1', '10', '100'], fontsize=8)
ax.set_xticks(range(len(types_v)))
ax.set_xticklabels([t2.replace('/MC', '-lineage').replace('fibroblast/MSC', 'Fibro/\nMSC')
                    .replace('/monocyte', '').replace(' cell', '').replace('/', '/\n') for t2 in types_v],
                   fontsize=7.6)
from matplotlib.patches import Patch
ax.legend([Patch(fc='#2166ac', alpha=0.75), Patch(fc='#b2182b', alpha=0.75)],
          ['low pain', 'high pain'], fontsize=8, frameon=False, loc='upper right')
ax.set_ylabel('% of synovial cells per patient (log)')
despine(ax)
su_v = json.loads(io.open(os.path.join(SCR, 'stats_upgrade.json'), encoding='utf-8').read())
ax.set_title('Donor-level composition split violins (exact PERMANOVA: F = %.2f, P = %.3f)' % (
    su_v['discovery_permanova']['F'], su_v['discovery_permanova']['p']), loc='left', fontsize=10.5)
panel_label(ax, 'C', dx=-0.14, dy=1.05)

# (D) fibroblast subcluster UMAP
ax = fig.add_subplot(gs[1, 1])
fib = adata[adata.obs['fib_subtype'].astype(str) != '-'].copy()
cats = fib.obs['fib_subtype'].astype(str)
order = sorted(cats.unique(), key=lambda c: -((cats == c).sum()))
pts = fib.obsm['X_umap']
lab_order = 0
fib_anns = []
for c in order:
    m = (cats == c).values
    ax.scatter(pts[m, 0], pts[m, 1], s=1.6, color=FIB_COLORS.get(c, '#bbbbbb'),
               alpha=0.85, rasterized=True, linewidths=0)
    if m.sum() >= 40 and c != 'unclassified':
        SHORT_D = {'lining CD55+': 'CD55+ lining', 'sublining THY1+': 'THY1+ sublin.',
                   'MSC-like DKK1/CXCL12+': 'DKK1+ MSC', 'CD34+ progenitor': 'CD34+ prog.',
                   'myofibroblast': 'Myofibro.'}
        cx, cy = pts[m, 0].mean(), pts[m, 1].mean()
        # offsets follow the real centroid geometry (THY1 right, CD55 below it,
        # DKK1 up-left, myofibro down-left, CD34 top-left) so boxes cannot meet
        OFF_D = {'myofibroblast': (-38, -34), 'lining CD55+': (46, -20),
                 'MSC-like DKK1/CXCL12+': (-30, 36), 'sublining THY1+': (40, 22),
                 'CD34+ progenitor': (-40, 40)}
        ox, oy = OFF_D.get(c, (32, -32))
        ann = ax.annotate(SHORT_D.get(c, c), (cx, cy), xytext=(ox, oy), textcoords='offset points',
                          fontsize=6.9, ha='center', va='center', fontweight='bold',
                          color='white', zorder=10,
                          bbox=dict(boxstyle='round,pad=0.22', fc='#333333', ec='none', alpha=0.85),
                          arrowprops=dict(arrowstyle='-', color='#333333', lw=0.8,
                                          shrinkA=1, shrinkB=3))
        fib_anns.append(ann)

# iterative repulsion: nudge label offsets apart until no two boxes overlap
# (displacement is capped so labels can never wander into neighbouring panels)
fig.canvas.draw()
_rend = fig.canvas.get_renderer()
_home = [a.get_position() for a in fib_anns]
for _ in range(60):
    moved = False
    boxes = [a.get_window_extent(renderer=_rend) for a in fib_anns]
    for i in range(len(fib_anns)):
        for j in range(i + 1, len(fib_anns)):
            b1, b2 = boxes[i], boxes[j]
            ix = max(0.0, min(b1.x1, b2.x1) - max(b1.x0, b2.x0))
            iy = max(0.0, min(b1.y1, b2.y1) - max(b1.y0, b2.y0))
            if ix * iy > 8:
                cx1, cy1 = (b1.x0 + b1.x1) / 2, (b1.y0 + b1.y1) / 2
                cx2, cy2 = (b2.x0 + b2.x1) / 2, (b2.y0 + b2.y1) / 2
                dx, dy = cx1 - cx2, cy1 - cy2
                nrm = (dx * dx + dy * dy) ** 0.5 or 1.0
                push = 3.0
                for k in (i, j):
                    sgn = 1.0 if k == i else -1.0
                    ann_k = fib_anns[k]
                    ox0, oy0 = ann_k.get_position()
                    nx = ox0 + sgn * push * dx / nrm
                    ny = oy0 + sgn * push * dy / nrm
                    hx, hy = _home[k]
                    nx = min(max(nx, hx - 34), hx + 34)
                    ny = min(max(ny, hy - 34), hy + 34)
                    ann_k.set_position((nx, ny))
                moved = True
    if not moved:
        break
    fig.canvas.draw()
    _rend = fig.canvas.get_renderer()
ax.set_xticks([]); ax.set_yticks([])
for sp_ in ax.spines.values():
    sp_.set_visible(False)
ax.set_title('Fibroblast/MSC-lineage subtypes', loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=0.0, dy=1.04)

# ===== (E, F) replication cohort: paired-slope charts =====
rda = pd.read_csv(os.path.join(SCR, 'replica_diff_abundance.csv'))
rfs = pd.read_csv(os.path.join(SCR, 'replica_fib_subtypes.csv'))
rprop = pd.read_csv(os.path.join(SCR, 'replica_per_sample_proportions.csv'), index_col=0)
rsamples = list(rprop.columns)
rmet = json.loads(io.open(os.path.join(SCR, 'replica_metrics.json'), encoding='utf-8').read())
rgrp = {s: rmet['samples'][s] for s in rsamples}

# (E) nested rings: inner = healthy median shares, outer = OA median shares
ax = fig.add_subplot(gs[2, 0])
import matplotlib.patches as mpatches
types_e = [t2 for t2 in rprop.index if t2 != 'unannotated']
types_e = sorted(types_e, key=lambda t2: -(rprop.loc[t2].mean()))
import matplotlib.cm as _cm
pal_e = list(plt.cm.tab10(np.linspace(0, 1, 10)))[:len(types_e)]
med_h = [float(np.median([max(rprop.loc[t2, s], 0.05) for s in rsamples if rgrp[s] == 'healthy'])) for t2 in types_e]
med_o = [float(np.median([max(rprop.loc[t2, s], 0.05) for s in rsamples if rgrp[s] == 'OA'])) for t2 in types_e]
tot_h, tot_o = sum(med_h), sum(med_o)
start = 90.0
for t2, mh, mo, c in zip(types_e, med_h, med_o, pal_e):
    th_h = 360.0 * mh / tot_h
    ax.add_patch(mpatches.Wedge((0, 0), 0.62, start - th_h, start, width=0.26,
                                facecolor=c, edgecolor='white', lw=1.2, alpha=0.9))
    start -= th_h
start = 90.0
for t2, mh, mo, c in zip(types_e, med_h, med_o, pal_e):
    th_o = 360.0 * mo / tot_o
    ax.add_patch(mpatches.Wedge((0, 0), 1.0, start - th_o, start, width=0.26,
                                facecolor=c, edgecolor='white', lw=1.2, alpha=0.72))
    am = np.deg2rad(start - th_o / 2)
    if mo / tot_o > 0.04:
        ax.text(0.87 * np.cos(am), 0.87 * np.sin(am), '%.0f%%' % (100 * mo / tot_o),
                ha='center', va='center', fontsize=8, color='#111111', fontweight='bold')
    start -= th_o
ax.add_patch(mpatches.Circle((0, 0), 0.36, facecolor='white', edgecolor='#333333', lw=1.0))
ax.text(0, 0.08, '93,105', ha='center', fontsize=10, fontweight='bold')
ax.text(0, -0.10, 'cells', ha='center', fontsize=8, color='#222222')
SHORT_E = {'macrophage/monocyte': 'Macrophage', 'fibroblast/MSC-lineage': 'Fibroblast/MSC',
           'endothelial cell': 'Endothelial', 'pericyte/SMC': 'Pericyte/SMC',
           'T/NK cell': 'T/NK', 'B/plasma cell': 'B/plasma', 'mast cell': 'Mast',
           'chondrocyte-like': 'Chondro-like', 'adipocyte': 'Adipocyte'}
handles_e = [mpatches.Patch(facecolor=pal_e[i], label=SHORT_E.get(types_e[i], types_e[i]))
             for i in range(len(types_e))]
ax.legend(handles=handles_e, loc='upper center', bbox_to_anchor=(0.5, -0.01), ncol=3, fontsize=7.2,
          frameon=True, framealpha=0.95, edgecolor='#cccccc', columnspacing=0.9,
          handlelength=1.1, handletextpad=0.4,
          title='inner ring = healthy, outer ring = OA', title_fontsize=7.8, borderpad=0.45)
ax.set_xlim(-1.15, 1.15); ax.set_ylim(-1.35, 1.15)
ax.set_aspect('equal'); ax.axis('off')
ax.set_title('Replication cohort: compartment shares\n(median per donor; no pair differs at exact P < 0.05)',
             loc='left', fontsize=10.5)
panel_label(ax, 'E', dx=-0.07, dy=1.02)

# (F) matrix heatmap: subtype shares healthy vs OA vs delta
ax = fig.add_subplot(gs[2, 1])
f3 = rfs.copy().sort_values('MWU_p')
rowsF = f3['subtype'].tolist()
colsF = ['healthy', 'OA', 'delta']
matF = np.array([[r['mean_healthy'], r['mean_OA'], r['mean_OA'] - r['mean_healthy']]
                 for _, r in f3.iterrows()])
import matplotlib.colors as mcolors
norm_h = mcolors.Normalize(vmin=0, vmax=matF[:, :2].max())
norm_d = mcolors.TwoSlopeNorm(vmin=-matF[:, 2].max(), vcenter=0, vmax=matF[:, 2].max())
for j in range(2):
    ax.imshow(matF[:, j:j + 1], cmap='YlGnBu', norm=norm_h, aspect='auto',
              extent=(j - 0.5, j + 0.5, len(rowsF) - 0.5, -0.5))
ax.imshow(matF[:, 2:3], cmap='RdBu_r', norm=norm_d, aspect='auto',
          extent=(1.5, 2.5, len(rowsF) - 0.5, -0.5))
for i in range(len(rowsF)):
    for j in range(2):
        v = matF[i, j]
        ax.text(j, i, '%.1f%%' % v, ha='center', va='center', fontsize=8.4,
                color='white' if v > matF[:, :2].max() * 0.6 else '#111111')
    ax.text(2, i, '%+.1f pp' % matF[i, 2], ha='center', va='center', fontsize=8.4,
            color='white' if abs(matF[i, 2]) > matF[:, 2].max() * 0.55 else '#111111')
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(['healthy mean', 'OA mean', 'delta'], fontsize=9)
ax.set_yticks(range(len(rowsF)))
ax.set_yticklabels(rowsF, fontsize=8.4)
ax.axvline(1.5, color='white', lw=2.5)
for i in range(len(rowsF)):
    if f3.iloc[i]['MWU_p'] < 0.1:
        ax.text(-0.42, i, '*', ha='center', va='center', fontsize=11,
                color='#b2182b', fontweight='bold')
ax.set_xlim(-0.50, 2.5)
ax.set_title('Replication cohort: fibroblast/MSC subtype shares\n(* nominal P < 0.1; exact MWU)', loc='left', fontsize=10.5)
panel_label(ax, 'F', dx=-0.16, dy=1.06)

# ===== (G) robustness: polar rose of log2FC across settings =====
rob = json.loads(io.open(os.path.join(SCR, 'robustness.json'), encoding='utf-8').read())
ax = fig.add_subplot(gs[3, 0], projection='polar')
rows_g = [('MT 20% main', 0.730469, 'main'), ('MT 15%', rob['mt15']['fibroblast/MSC-lineage']['log2FC'], 'qc'),
          ('MT 10%', rob['mt10']['fibroblast/MSC-lineage']['log2FC'], 'qc')]
for s in rob['multiseed']:
    rows_g.append(('seed %d @ %d%%' % (s['seed'], int(s['frac'] * 100)),
                   np.log2((s['fib_high'] + 0.1) / (s['fib_low'] + 0.1)), 'seed'))
N = len(rows_g)
theta = np.linspace(0, 2 * np.pi, N, endpoint=False)
rmax = max(r[1] for r in rows_g) * 2.05
SHORT_G = ['MT 20%', 'MT 15%', 'MT 10%', 's0-80', 's0-50', 's1-80', 's1-50', 's2-80', 's2-50']
fmax = max(r[1] for r in rows_g)
for th, (lab, fc, grp) in zip(theta, rows_g):
    colr = PALETTE['main'] if grp in ('main', 'qc') else PALETTE['third']
    w = 2 * np.pi / N * 0.62
    ax.bar(th, fc, width=w, color=colr, edgecolor='white', lw=1.0)
    # value labels sit above every bar top: dark text on a white patch, never
    # white on colour and never dark on colour
    ax.text(th, fmax * 1.05, '%+.2f' % fc, ha='center', va='center',
            fontsize=8.6, color='#111111', fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.12', fc='white', ec='none'))
ax.set_xticks(theta)
ax.set_xticklabels([])
ax.set_ylim(0, rmax)
ax.set_yticks([])
ax.grid(alpha=0.25, lw=0.7, color='#bbbbbb')
ax.spines['polar'].set_visible(False)
# short rim labels rotated along the spoke: they stay inside the panel box
for th, s in zip(theta, SHORT_G):
    rot = np.degrees(th)
    if np.cos(th) < 0:
        rot += 180
    ax.text(th, fmax * 1.72, s, rotation=rot, ha='center', va='center',
            fontsize=8.0, color='#111111', fontweight='bold')
ax.text(0, 0, 'all nine\nP = 0.029', ha='center', va='center', fontsize=8.8,
        color='#111111', fontweight='bold', linespacing=1.25,
        bbox=dict(boxstyle='round,pad=0.28', fc='white', ec='#111111', lw=0.9))
ax.set_title('Robustness: fibroblast/MSC log2FC across nine settings (all exact P = 0.029)',
             fontsize=10, pad=22)
ax.text(-0.30, 1.02, 'G', transform=ax.transAxes, fontsize=13, fontweight='bold',
        va='bottom', ha='right')

# ===== (H) donor-confound check: sorted lollipop of per-cluster donor dominance =====
ax = fig.add_subplot(gs[3, 1])
cty = pd.crosstab(adata.obs['leiden'], adata.obs['sample'])
frac1 = (cty.max(axis=1) / cty.sum(axis=1)).sort_values()
vals_h = frac1.values.astype(float)
ypos = np.arange(len(vals_h))
cols_h = ['#b2182b' if v > 0.8 else PALETTE['main'] for v in vals_h]
ax.hlines(ypos, 0.35, vals_h, color=cols_h, lw=1.6, alpha=0.85)
ax.scatter(vals_h, ypos, s=34, color=cols_h, edgecolors='white', linewidths=0.6, zorder=4)
med_h2 = float(np.median(vals_h))
ax.axvline(0.8, color='#b2182b', lw=1.6, ls='--')
ax.axvline(med_h2, color='#111111', lw=1.8)
ax.text(0.8, len(vals_h) * 0.02, '80% single-donor threshold', fontsize=8.2,
        color='#b2182b', fontweight='bold', ha='center', va='bottom')
# labels sit in the empty corners so nothing covers the stems or dots
ax.text(med_h2, -1.05, 'median %.2f' % med_h2, fontsize=8.2, ha='center',
        va='top', color='#111111', fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.14', fc='white', ec='none'))
ax.text(1.0, 5.6,
        '%d/%d clusters > 80%%\nsingle donor\n(%.1f%% of all cells)' % (
            rob['donor_confound']['clusters_gt80pct_single_donor'],
            rob['donor_confound']['n_clusters'],
            100.0 * rob['donor_confound']['cells_in_gt80pct_clusters'] / rob['donor_confound']['n_cells']),
        fontsize=8.4, color='#b2182b', fontweight='bold', va='center', ha='right',
        bbox=dict(boxstyle='round,pad=0.28', fc='white', ec='#b2182b', lw=0.9))
ax.set_xlim(0.33, 1.02)
ax.set_ylim(-2.2, len(vals_h) + 0.6)
ax.set_yticks([])
ax.set_xlabel('Largest single-donor share of each Leiden cluster')
despine(ax, sides=('top', 'right', 'left'))
ax.set_title('Donor-confound check: one dot = one Leiden cluster\n(sorted; red = cluster dominated by a single donor)',
             loc='left', fontsize=10.5)
panel_label(ax, 'H', dx=-0.12, dy=1.06)

fig.savefig(os.path.join(FIG, 'Fig6_scrna_atlas.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig6_scrna_atlas.pdf'), dpi=920)
plt.close(fig)
print('Fig6 saved')

# ================= FIG 7 =================
fig = plt.figure(figsize=(12, 9.2))
gs = fig.add_gridspec(2, 2, hspace=0.21, wspace=0.18, left=0.16, right=0.96, top=0.93, bottom=0.08)

# (A) treemap of absolute effects, colour = direction
ax = fig.add_subplot(gs[0, 0])
import squarify
from matplotlib.patches import Rectangle
d2 = da[da['cell_type'] != 'unannotated'].copy()
d2['absx'] = d2['log2FC_high_vs_low'].abs()
d2 = d2.sort_values('absx', ascending=False)
sizes = d2['absx'].tolist()
cols_t = ['#b2182b' if r['log2FC_high_vs_low'] > 0 else '#2166ac' for _, r in d2.iterrows()]
# draw tiles manually so every tile gets a crisp white boundary and the
# label font shrinks with tile area (no text can overflow its tile)
norm = squarify.normalize_sizes(sizes, 100, 100)
rects = squarify.squarify(norm, 0, 0, 100, 100)
tile_texts = []
for rect, c, (_, row) in zip(rects, cols_t, d2.iterrows()):
    ax.add_patch(Rectangle((rect['x'], rect['y']), rect['dx'], rect['dy'],
                           facecolor=c, alpha=0.9, edgecolor='white', lw=2.2))
    area = rect['dx'] * rect['dy']
    name = row['cell_type'].replace('/monocyte', ' monocyte').replace('/MSC-lineage', ' MSC-lin.')
    if area > 1500:
        txt = '%s\n%+.2f\nP=%.3f' % (name, row['log2FC_high_vs_low'], row['MWU_p'])
        fs = 7.6
    elif area > 300:
        txt = '%s\n%+.2f' % (name.replace(' monocyte', '/mono').replace(' MSC-lin.', '/MSC'),
                             row['log2FC_high_vs_low'])
        fs = 6.8
    else:
        txt = '%+.2f' % row['log2FC_high_vs_low']
        fs = 6.2
    t = ax.text(rect['x'] + rect['dx'] / 2, rect['y'] + rect['dy'] / 2, txt,
                ha='center', va='center', fontsize=fs, color='white', fontweight='bold',
                linespacing=1.3, clip_on=True)
    tile_texts.append((t, rect))
ax.set_xlim(0, 100); ax.set_ylim(0, 100)
ax.set_aspect('equal')
ax.axis('off')
# exact renderer-based fit: shrink each label until its box is inside its own tile
fig.canvas.draw()
_rend = fig.canvas.get_renderer()
for t, rect in tile_texts:
    p0 = ax.transData.transform((rect['x'] + rect['dx'] * 0.05, rect['y'] + rect['dy'] * 0.05))
    p1 = ax.transData.transform((rect['x'] + rect['dx'] * 0.95, rect['y'] + rect['dy'] * 0.95))
    maxw = abs(p1[0] - p0[0]); maxh = abs(p1[1] - p0[1])
    fs = t.get_fontsize()
    bb = t.get_window_extent(renderer=_rend)
    while (bb.width > maxw or bb.height > maxh) and fs > 4.2:
        fs -= 0.3
        t.set_fontsize(fs)
        bb = t.get_window_extent(renderer=_rend)
ax.set_title('Differential abundance (area = |log2FC|;\nred = higher in high pain, blue = lower)',
             loc='left', fontsize=10.5)
panel_label(ax, 'A', dx=0.0, dy=1.04)

# (B, C) donor x cell-type module matrices
samples_v2 = list(adata.obs['sample'].unique())
pain_of_v2 = {s: ('high' if 'high' in s else 'low') for s in samples_v2}
types_v2 = [c for c in adata.obs['cell_type'].value_counts().index if c != 'unannotated']
donors_sorted = sorted(samples_v2, key=lambda s: (pain_of_v2[s] == 'high', s))
for k, (modname, lab, letter) in enumerate([('senescence_core', 'Senescence-core module', 'B'),
                                            ('sasp', 'SASP module', 'C')]):
    ax = fig.add_subplot(gs[0, 1] if k == 0 else gs[1, 0])
    keep_types = []
    matM = []
    ps_M = []
    for ct in types_v2:
        row = []
        for s in donors_sorted:
            m = (adata.obs['sample'] == s) & (adata.obs['cell_type'] == ct)
            row.append(float(adata.obs.loc[m, 'mod_' + modname].mean()) if m.sum() >= 10 else np.nan)
        hi = [v for v, s in zip(row, donors_sorted) if pain_of_v2[s] == 'high' and v == v]
        lo = [v for v, s in zip(row, donors_sorted) if pain_of_v2[s] == 'low' and v == v]
        if len(hi) >= 3 and len(lo) >= 3:
            u, pv = sps.mannwhitneyu(hi, lo, alternative='two-sided')
        else:
            pv = np.nan
        keep_types.append(ct)
        matM.append(row)
        ps_M.append(pv)
    matM = np.array(matM, dtype=float)
    import matplotlib.colors as mcolors
    vmax = np.nanmax(np.abs(matM))
    im = ax.imshow(matM, cmap='RdBu_r', norm=mcolors.TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax),
                   aspect='auto')
    for i in range(matM.shape[0]):
        for j in range(matM.shape[1]):
            v = matM[i, j]
            ax.text(j, i, ('%.2f' % v) if v == v else '', ha='center', va='center',
                    fontsize=6.8, color='white' if abs(v) > vmax * 0.55 else '#111111')
    ax.set_xticks(range(len(donors_sorted)))
    ax.set_xticklabels([s.replace('DK', 'D').replace('_high', 'H').replace('_low', 'L') for s in donors_sorted],
                       fontsize=7.4, rotation=45, ha='right')
    for j, s in enumerate(donors_sorted):
        ax.text(j, -1.05, 'high' if pain_of_v2[s] == 'high' else 'low', ha='center',
                fontsize=7, color='#b2182b' if pain_of_v2[s] == 'high' else '#2166ac', fontweight='bold')
    ax.set_ylim(len(keep_types) - 0.5, -1.55)
    ax.set_yticks(range(len(keep_types)))
    ax.set_yticklabels(keep_types, fontsize=8.2)
    for i, pv in enumerate(ps_M):
        if pv == pv:
            star = '***' if pv <= 0.001 else '**' if pv <= 0.01 else '*' if pv <= 0.05 else 'ns'
            ax.text(matM.shape[1] - 0.35, i, star, ha='left', va='center',
                    fontsize=8, fontweight='bold', color='#222222')
    ax.set_title(lab + ' — donor × cell-type matrix (exact MWU)',
                 loc='left', fontsize=10.5, pad=10)
    plt.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
    panel_label(ax, letter, dx=-0.18, dy=1.12)

# (D) bipartite arc network: macrophage ligands -> fibroblast receptors
ax = fig.add_subplot(gs[1, 1])
lr3 = lr.copy()
perm_lr3 = {r['ligand'] + '->' + r['receptor']: r for r in
            json.loads(io.open(os.path.join(SCR, 'perm_lr.json'), encoding='utf-8').read())}
lr3 = lr3.nlargest(10, 'score_macro_fib').reset_index(drop=True)
N = len(lr3)
xL, xR = 0.12, 0.88
yL = np.linspace(0.06, 0.94, N)
# sort by ligand mean to give the arc bundle a flow
lr3 = lr3.sort_values('macrophage_L', ascending=False).reset_index(drop=True)
yR = np.linspace(0.06, 0.94, N)
sc_max = lr3['score_macro_fib'].max()
for i, r in lr3.iterrows():
    key = r['ligand'] + '->' + r['receptor']
    sig = perm_lr3.get(key, {}).get('p_emp', 1) <= 0.01
    colr = '#7d3c98' if sig else '#b3b3b3'
    lw = 1.2 + 6.0 * (r['score_macro_fib'] / sc_max)
    verts = [(xL, yL[i]), (0.5, yL[i]), (0.5, yR[i]), (xR, yR[i])]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4]
    ax.add_patch(PathPatch(Path(verts, codes), facecolor='none',
                           edgecolor=colr, lw=lw, alpha=0.75, capstyle='round'))
    ax.scatter([xL], [yL[i]], s=90 if sig else 55, color='#b2182b', zorder=5,
               edgecolors='white', linewidths=1.0)
    ax.scatter([xR], [yR[i]], s=90 if sig else 55, color='#2166ac', zorder=5,
               edgecolors='white', linewidths=1.0)
    ax.text(xL - 0.03, yL[i], '%s%s' % (r['ligand'], ' **' if sig else ''),
            ha='right', va='center', fontsize=8.2,
            color='#222222' if sig else '#555555', fontweight='bold' if sig else 'normal')
    ax.text(xR + 0.03, yR[i], '%s%s' % (r['receptor'], ' **' if sig else ''),
            ha='left', va='center', fontsize=8.2,
            color='#222222' if sig else '#555555', fontweight='bold' if sig else 'normal')
ax.plot([xL, xL], [0.02, 0.98], color='#b2182b', lw=2.2)
ax.plot([xR, xR], [0.02, 0.98], color='#2166ac', lw=2.2)
ax.text(xL - 0.03, 1.02, 'Macrophage ligands', ha='right', fontsize=9.0,
        color='#b2182b', fontweight='bold')
ax.text(xR + 0.03, 1.02, 'Fibroblast/MSC receptors', ha='left', fontsize=9.0,
        color='#2166ac', fontweight='bold')
ax.set_xlim(-0.34, 1.34); ax.set_ylim(0, 1.12)
ax.axis('off')
ax.set_title('Macrophage-to-fibroblast crosstalk arcs\n(width = mean-expression product; ** = permutation P <= 0.01)',
             loc='left', fontsize=10.5)
panel_label(ax, 'D', dx=0.0, dy=1.02)

fig.savefig(os.path.join(FIG, 'Fig7_scrna_mechanism.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig7_scrna_mechanism.pdf'), dpi=920)
plt.close(fig)
print('Fig7 saved')
