# -*- coding: utf-8 -*-
"""Registry analysis: all numbers for text+figures, saved to JSON + figure CSVs."""
import io, os, json, re, glob
import pandas as pd
import numpy as np
import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, 'results', 'registry')
FULL = os.path.join(BASE, 'data', 'ctgov_full')

df = pd.read_csv(os.path.join(OUT, 'trials_ortho_clean.csv'), dtype=str)
df['phase'] = df['phase'].replace({'NA': 'not applicable'})
df['enrollment_num'] = pd.to_numeric(df['enrollment'], errors='coerce')

def parse_year(s):
    try:
        return int(str(s)[:4])
    except Exception:
        return None

df['start_year'] = df['start'].map(parse_year)
df['pc_year'] = df['primary_completion'].map(parse_year)

A = {}
A['n_trials'] = int(len(df))
A['pull_counts'] = json.loads(io.open(os.path.join(BASE, 'data', 'ctgov2_download.log'), encoding='utf-8').read().split('UNION')[0].replace('[', '').replace(']', '').strip()) if False else None

# ---- cross tabs
fam_order = ['knee osteoarthritis', 'hip osteoarthritis', 'other osteoarthritis',
             'cartilage defect/injury', 'fracture/bone defect', 'tendon/ligament/meniscus',
             'spine degeneration/fusion', 'osteonecrosis', 'osteoporosis', 'other musculoskeletal']
fam_counts = df['family'].value_counts()
A['family_counts'] = {k: int(fam_counts.get(k, 0)) for k in fam_order}

def status_group(s):
    if s in ('RECRUITING', 'ACTIVE_NOT_RECRUITING', 'ENROLLING_BY_INVITATION', 'NOT_YET_RECRUITING', 'AVAILABLE'):
        return 'active'
    if s == 'COMPLETED':
        return 'completed'
    if s in ('TERMINATED', 'WITHDRAWN', 'SUSPENDED', 'NO_LONGER_AVAILABLE'):
        return 'discontinued'
    return 'unknown status'

df['status_grp'] = df['status'].map(status_group)
A['status_groups'] = df['status_grp'].value_counts().to_dict()
ct = pd.crosstab(df['family'], df['status_grp'])
ct.to_csv(os.path.join(OUT, 'fig_family_status.csv'))
A['family_status'] = ct.to_dict()

# temporal
yr = df.dropna(subset=['start_year']).copy()
yr['start_year'] = yr['start_year'].astype(int)
yr = yr[(yr['start_year'] >= 2000) & (yr['start_year'] <= 2026)]
A['year_range'] = [int(yr['start_year'].min()), int(yr['start_year'].max())]
A['trials_per_year'] = yr['start_year'].value_counts().sort_index().to_dict()
yt = pd.crosstab(yr['start_year'], yr['family'])
yt.to_csv(os.path.join(OUT, 'fig_year_family.csv'))
# autologous share by year
oy = pd.crosstab(yr['start_year'], yr['origin'])
oy.to_csv(os.path.join(OUT, 'fig_year_origin.csv'))

# source
src_ct = pd.crosstab(df['family'], df['source'])
src_ct.to_csv(os.path.join(OUT, 'fig_family_source.csv'))
A['source_counts'] = df['source'].value_counts().to_dict()
A['origin_counts'] = df['origin'].value_counts().to_dict()
A['product_counts'] = df['product'].value_counts().to_dict()

# phase
A['phase_counts'] = df['phase'].value_counts().to_dict()
ph_ct = pd.crosstab(df['family'], df['phase'])
ph_ct.to_csv(os.path.join(OUT, 'fig_family_phase.csv'))

# geography
geo = {}
for s in df['countries'].fillna(''):
    for c in s.split(';'):
        c = c.strip()
        if c:
            geo[c] = geo.get(c, 0) + 1
A['countries'] = dict(sorted(geo.items(), key=lambda kv: -kv[1]))
n_multi = int((df['n_countries'].fillna('0').astype(int) > 1).sum())
A['n_multinational'] = n_multi

# sponsors
A['lead_class'] = df['lead_class'].value_counts().to_dict()

# enrollment
en = df['enrollment_num'].dropna()
A['enrollment'] = {'n': int(en.notna().sum()), 'median': float(en.median()),
                   'q1': float(en.quantile(0.25)), 'q3': float(en.quantile(0.75)),
                   'min': float(en.min()), 'max': float(en.max())}
en_fam = df.dropna(subset=['enrollment_num']).groupby('family')['enrollment_num'].agg(
    ['count', 'median', 'mean', lambda x: x.quantile(0.25), lambda x: x.quantile(0.75)])
en_fam.columns = ['n', 'median', 'mean', 'q1', 'q3']
en_fam.to_csv(os.path.join(OUT, 'fig_enrollment_family.csv'))

# outcomes
dom_counts = {}
n_prim = []
for s in df['primary_domains'].fillna(''):
    if s.strip():
        for d in s.split(';'):
            dom_counts[d] = dom_counts.get(d, 0) + 1
A['primary_domains'] = dom_counts
A['n_primary_measures_median'] = float(pd.to_numeric(df['primary_outcome_n'], errors='coerce').median())
A['n_no_primary_outcome'] = int((pd.to_numeric(df['primary_outcome_n'], errors='coerce') == 0).sum())
A['share_any_pain'] = float(np.mean(df['primary_domains'].fillna('').str.contains('pain')))
A['share_any_imaging'] = float(np.mean(df['primary_domains'].fillna('').str.contains('imaging')))

# results reporting
A['n_results'] = int((df['has_results'] == 'True').sum())
A['share_results'] = A['n_results'] / A['n_trials']
res = df[df['has_results'] == 'True'].copy()
res_fam = res['family'].value_counts().to_dict()
A['results_by_family'] = {k: int(v) for k, v in res_fam.items()}
# posting lag
def lag_years(row):
    try:
        s = pd.Timestamp(row['primary_completion'])
        e = pd.Timestamp(row['results_first_posted'])
        return (e - s).days / 365.25
    except Exception:
        return None
res['post_lag_y'] = res.apply(lag_years, axis=1)
A['results_post_lag_median_y'] = float(res['post_lag_y'].dropna().median()) if len(res) else None
res[['nct', 'family', 'post_lag_y']].to_csv(os.path.join(OUT, 'fig_results_lag.csv'), index=False)

# discontinued reasons
disc = df[df['status_grp'] == 'discontinued']
why = disc[disc['why_cat'].fillna('') != '']
A['n_discontinued'] = int(len(disc))
A['n_discontinued_with_reason'] = int(len(why))
A['discontinued_reasons'] = why['why_cat'].value_counts().to_dict()
A['n_withdrawn'] = int((df['status'] == 'WITHDRAWN').sum())
A['n_terminated'] = int((df['status'] == 'TERMINATED').sum())

# trial duration (start -> primary completion)
dur = []
for _, r in df.iterrows():
    try:
        s = pd.Timestamp(r['start'])
        e = pd.Timestamp(r['primary_completion'])
        if pd.notna(s) and pd.notna(e) and e > s:
            dur.append((e - s).days / 365.25)
    except Exception:
        pass
A['trial_duration_median_y'] = float(np.median(dur)) if dur else None
A['trial_duration_n'] = len(dur)

# ---- dose extraction from full records
DOSE_X10 = re.compile(r'(\d+(?:[.,]\d+)?)\s*[×x]\s*10\s*\^?\s*(\d+)')
DOSE_M = re.compile(r'(\d+(?:[.,]\d+)?)\s*million', re.I)
dose_rows = []
for p in glob.glob(os.path.join(FULL, 'full_*.json')):
    try:
        st = json.loads(io.open(p, encoding='utf-8').read())
    except Exception:
        continue
    nct = st['protocolSection']['identificationModule']['nctId']
    prot = st['protocolSection']
    arms = prot.get('armsInterventionsModule', {})
    desc = prot.get('descriptionModule', {})
    txt = ' | '.join((i.get('name') or '') + ' ' + (i.get('otherName') or '') for i in (arms.get('interventions') or []))
    txt += ' | ' + ' | '.join((a.get('label') or '') + ' ' + (a.get('description') or '') for a in (arms.get('armGroups') or []))
    txt += ' | ' + (desc.get('detailedDescription') or '')[:6000]
    vals = []
    for m in DOSE_X10.finditer(txt):
        try:
            vals.append(float(m.group(1).replace(',', '')) * (10 ** int(m.group(2))))
        except Exception:
            pass
    for m in DOSE_M.finditer(txt):
        try:
            vals.append(float(m.group(1).replace(',', '')) * 1e6)
        except Exception:
            pass
    vals = [v for v in vals if 1e3 <= v <= 1e11]
    if vals:
        fam = df.loc[df['nct'] == nct, 'family']
        dose_rows.append({'nct': nct, 'family': fam.iloc[0] if len(fam) else '',
                          'max_dose': max(vals), 'min_dose': min(vals), 'n_dose_mentions': len(vals)})
dd = pd.DataFrame(dose_rows)
dd.to_csv(os.path.join(OUT, 'fig_doses.csv'), index=False)
A['n_dose_numeric'] = int(len(dd))
A['dose_share_of_with_n'] = float(len(dd) / len(df))
if len(dd):
    A['dose_median'] = float(dd['max_dose'].median())
    A['dose_min'] = float(dd['min_dose'].min())
    A['dose_max'] = float(dd['max_dose'].max())
    A['dose_fold_range'] = float(dd['max_dose'].max() / dd['min_dose'].min())

io.open(os.path.join(OUT, 'registry_analysis.json'), 'w', encoding='utf-8').write(
    json.dumps(A, indent=1, ensure_ascii=False, default=str))
print(json.dumps(A, indent=1, ensure_ascii=False, default=str)[:3500])
