# -*- coding: utf-8 -*-
"""Classify registry v2 candidates (condition-scoped API pulls) into the analytic set."""
import io, os, json, re, hashlib, datetime
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
RAW2 = os.path.join(BASE, 'data', 'ctgov_raw2')
OUT = os.path.join(BASE, 'results', 'registry')
os.makedirs(OUT, exist_ok=True)

MSC_RX = re.compile(r'mesenchymal|stromal cell|stromal vascular|\bMSC\b|\bmMSC\b|stem cell|aspirate concentrate|marrow aspirate|micro-?fragmented|\bSVF\b|progenitor cell', re.I)
EXCLUDE_RX = re.compile(
    r'dental|periodont|tooth|gingiv|alveolar|maxilla|mandib|jaw\b|oral\b|'
    r'skin|wound|dermat|cutaneous|ulcer|burn|scar|hair|scalp|'
    r'cornea|ocular|retina|optic|dry eye|'
    r'cardiac|heart|myocard|cardio|stroke|cerebral|cerebr|parkinson|alzheimer|'
    r'multiple sclerosis|spinal cord injury|muscular dystrophy|\bALS\b|autism|cerebral palsy|'
    r'crohn|colitis|inflammatory bowel|\bIBD\b|diabet|kidney|renal|liver|cirrho|hepat|'
    r'\bCOPD\b|asthma|pulmonary|COVID|SARS|HIV|lupus|\bSLE\b|scleroderma|graft.vs.host|'
    r'leukem|lymphoma|cancer|tumor|carcinoma|sarcoma|metasta|breast|prostate|bladder|'
    r'erectile|incontinence|fistula|perianal', re.I)
KNEE_OA_RX = re.compile(r'knee.{0,40}osteoarthritis|osteoarthrit.{0,40}knee|gonarthrosis|osteoarthr.{0,10}knee', re.I)
HIP_OA_RX = re.compile(r'hip.{0,40}osteoarthritis|osteoarthrit.{0,40}hip|coxarthrosis', re.I)
OA_RX = re.compile(r'osteoarthritis|arthrosis|degenerative joint', re.I)
CART_RX = re.compile(r'cartilage|chondral|chondromalacia|osteochondral', re.I)
BONE_RX = re.compile(r'fracture|non-?union|delayed union|pseudarthrosis|bone defect|osseous defect|bone regeneration|bone loss|osteogenesis imperfecta', re.I)
SPINE_RX = re.compile(r'spinal fusion|spondylolisthesis|intervertebral|disc degeneration|disc herniation|degenerative disc|vertebroplasty|kyphoplasty', re.I)
TEND_RX = re.compile(r'tendon|tendinopathy|tendinitis|rotator cuff|epicondyl|achilles|cruciate|ligament|menisc|tenosynov', re.I)
ONEC_RX = re.compile(r'osteonecrosis|avascular necrosis|femoral head', re.I)
OP_RX = re.compile(r'osteoporos|osteopenia', re.I)
OI_RX = re.compile(r'osteogenesis imperfecta', re.I)
MSKGEN_RX = re.compile(r'musculoskeletal|bone disease|joint disease|orthoped', re.I)

BM_RX = re.compile(r'bone marrow|marrow|\bBMAC\b|\bbMSC\b|\bBM-?MSC\b', re.I)
AD_RX = re.compile(r'adipose|adip-derived|\bAT-?MSC|\baMSC\b|stromal vascular|\bSVF\b|lipogems|micro-?fragment|lipoaspirate', re.I)
UC_RX = re.compile(r'umbilical|cord blood|wharton|uc-?msc', re.I)
SYN_RX = re.compile(r'synovial|synoviocyte', re.I)
PON_RX = re.compile(r'stromal vascular fraction|\bSVF\b|micro-?fragmented|aspirate concentrate|\bBMAC\b|bone marrow aspirate|adipose (?:tissue )?concentrate|point.of.care|minimally manipulated', re.I)
ALLO_RX = re.compile(r'allogene|donor|third.party|off.the.shelf', re.I)
AUTO_RX = re.compile(r'autolog', re.I)
DOSE_RX = re.compile(r'(\d+(?:[.,]\d+)?)\s*(?:[×x]\s*10\s*\^?\s*(\d+)|million|millicell?)', re.I)
DOSE_X10 = re.compile(r'(\d+(?:[.,]\d+)?)\s*[×x]\s*10\s*\^?\s*(\d+)')

OUTCOME_DOMS = [
    ('pain', re.compile(r'pain|VAS\b|visual analog|NRS\b|PROMIS pain', re.I)),
    ('function', re.compile(r'function|WOMAC|KOOS|Lysholm|IKDC|Harris|Oxford|Tegner|Merle|DASH|disability|mobility|gait|ROM\b|range of motion', re.I)),
    ('imaging/structure', re.compile(r'MRI|magnetic|radiograph|x-?ray|cartilage volume|T2 (?:mapping|relax)|Kellgren|ICRS|MOAKS|WORMS|thickness|ultrasound', re.I)),
    ('safety', re.compile(r'adverse|safety|complication|tolerab', re.I)),
    ('quality of life', re.compile(r'quality of life|EQ-5D|SF-?\d+|satisfaction|\bQOL\b', re.I)),
    ('biomarker/biology', re.compile(r'biomarker|serum|plasma|synovial fluid|histolog|biopsy|inflammatory|CRP\b|chondrogenesis', re.I)),
    ('response rate', re.compile(r'responder|response rate|OARSI.?RESPOND|treatment failure|rescue', re.I)),
]

def outcome_domains(txt):
    return [d for d, rx in OUTCOME_DOMS if rx.search(txt)]

TERM_CATS = [
    ('recruitment/enrollment', re.compile(r'enroll|recruit|accrual', re.I)),
    ('COVID-19 pandemic', re.compile(r'covid|pandemic', re.I)),
    ('funding/resource', re.compile(r'fund|financial|budget|resource', re.I)),
    ('business/strategic', re.compile(r'business|strategic|corporate|portfolio|priorit|commercial', re.I)),
    ('safety/medical', re.compile(r'safety|adverse|harm|toxic|ethical', re.I)),
    ('operational/administrative', re.compile(r'investigator|site|administrative|regulatory|moving|relocat|staff|operational', re.I)),
]

def term_category(txt):
    for c, rx in TERM_CATS:
        if rx.search(txt):
            return c
    return 'unspecified/other'

def classify_family(cond_txt, brief, title):
    t = cond_txt if cond_txt.strip() else (title + ' ' + brief[:200])
    if KNEE_OA_RX.search(t): return 'knee osteoarthritis'
    if HIP_OA_RX.search(t): return 'hip osteoarthritis'
    if OA_RX.search(t): return 'other osteoarthritis'
    if CART_RX.search(t): return 'cartilage defect/injury'
    if ONEC_RX.search(t): return 'osteonecrosis'
    if SPINE_RX.search(t): return 'spine degeneration/fusion'
    if TEND_RX.search(t): return 'tendon/ligament/meniscus'
    if BONE_RX.search(t): return 'fracture/bone defect'
    if OI_RX.search(t): return 'osteogenesis imperfecta'
    if OP_RX.search(t): return 'osteoporosis'
    if MSKGEN_RX.search(t): return 'other musculoskeletal'
    return 'other musculoskeletal'

def parse_dose(text):
    """Return numeric cell count if parseable."""
    m = DOSE_X10.search(text)
    if m:
        try:
            mant = float(m.group(1).replace(',', ''))
            exp = int(m.group(2))
            return mant * (10 ** exp)
        except Exception:
            return None
    m2 = re.search(r'(\d+(?:[.,]\d+)?)\s*million', text, re.I)
    if m2:
        try:
            return float(m2.group(1).replace(',', '')) * 1e6
        except Exception:
            return None
    return None

rows = []
audit = {'pulled': 0, 'excluded_non_msk': 0, 'included': 0}
for fn in sorted(os.listdir(RAW2)):
    if not fn.startswith('cand2_'):
        continue
    try:
        st = json.loads(io.open(os.path.join(RAW2, fn), encoding='utf-8').read())
    except Exception:
        continue
    audit['pulled'] += 1
    p = st.get('protocolSection', {})
    idm = p.get('identificationModule', {})
    nct = idm.get('nctId')
    stmod = p.get('statusModule', {})
    desc = p.get('descriptionModule', {})
    design = p.get('designModule', {})
    arms = p.get('armsInterventionsModule', {})
    sponsor = p.get('sponsorCollaboratorsModule', {})
    contacts = p.get('contactsLocationsModule', {})
    outcomes = p.get('outcomesModule', {})
    el = p.get('eligibilityModule', {})
    refmod = p.get('referencesModule') or {}
    if isinstance(refmod, dict):
        refmod = refmod.get('referenceList') or []

    int_txt = ' | '.join((i.get('name') or '') + ' ' + (i.get('otherName') or '')
                         for i in (arms.get('interventions') or []))
    cond_txt = ' | '.join(el.get('conditions') or [])
    brief = desc.get('briefSummary') or ''
    title = idm.get('briefTitle') or ''
    search_txt = cond_txt if cond_txt.strip() else (title + ' ' + brief[:400])
    if EXCLUDE_RX.search(search_txt) and not KNEE_OA_RX.search(search_txt):
        # mixed/non-MSK conditions — check each condition entry
        conds = [c for c in (el.get('conditions') or []) if EXCLUDE_RX.search(c)]
        if conds:
            audit['excluded_non_msk'] += 1
            continue
    family = classify_family(cond_txt, brief, title)
    src_txt = int_txt + ' ' + brief[:500]
    src = ('bone marrow' if BM_RX.search(src_txt) else
           'adipose tissue' if AD_RX.search(src_txt) else
           'umbilical cord' if UC_RX.search(src_txt) else
           'synovial' if SYN_RX.search(src_txt) else 'other/unspecified')
    origin = ('allogeneic' if ALLO_RX.search(src_txt) else
              'autologous' if AUTO_RX.search(src_txt) else 'not specified')
    product = ('point-of-care / minimally manipulated' if PON_RX.search(src_txt)
               else 'culture-expanded' if re.search(r'cultured|culture.expanded|expanded|passage', src_txt, re.I)
               else 'not specified')
    status = stmod.get('overallStatus')
    why = stmod.get('whyStopped') or ''
    phase = design.get('phases') or []
    phase_s = ','.join(phase) if phase else 'not applicable'
    prim = outcomes.get('primaryOutcomes') or []
    doms = []
    for o in prim:
        doms += outcome_domains(o.get('measure') or '')
    doms = sorted(set(doms))
    locs = contacts.get('locations') or []
    countries = sorted(set((l.get('locationCountry') or l.get('country') or '').strip() for l in locs if (l.get('locationCountry') or l.get('country'))))
    lead = (sponsor.get('leadSponsor') or {}).get('name') or ''
    lead_class = (sponsor.get('leadSponsor') or {}).get('class') or ''
    enroll = (design.get('enrollmentInfo') or {}).get('count')
    pmids = [r.get('pmid') for r in refmod if isinstance(r, dict) and r.get('pmid')]
    dose = parse_dose(int_txt)
    rows.append({
        'nct': nct, 'family': family, 'status': status, 'phase': phase_s,
        'source': src, 'origin': origin, 'product': product,
        'start': stmod.get('startDateStruct', {}).get('date'),
        'primary_completion': stmod.get('primaryCompletionDateStruct', {}).get('date'),
        'completion': stmod.get('completionDateStruct', {}).get('date'),
        'results_first_posted': stmod.get('resultsFirstPostDateStruct', {}).get('date'),
        'why_stopped': why, 'why_cat': term_category(why) if why else '',
        'enrollment': enroll,
        'interventions': int_txt[:600], 'conditions': cond_txt[:400],
        'countries': ';'.join(countries), 'n_countries': len(countries),
        'lead_sponsor': lead, 'lead_class': lead_class,
        'primary_outcome_n': len(prim), 'primary_domains': ';'.join(doms),
        'purpose': (design.get('designInfo') or {}).get('primaryPurpose') or '',
        'allocation': (design.get('designInfo') or {}).get('allocation') or '',
        'pmids': ';'.join(str(x) for x in pmids),
        'has_results': bool(st.get('hasResults')),
        'dose_reported': dose is not None or bool(DOSE_RX.search(int_txt)),
        'dose_value': dose,
    })

df = pd.DataFrame(rows)
df.to_csv(os.path.join(OUT, 'trials_ortho_v2.csv'), index=False)
audit['included'] = len(df)
audit['status_counts'] = df['status'].value_counts().to_dict()
audit['family_counts'] = df['family'].value_counts().to_dict()
audit['source_counts'] = df['source'].value_counts().to_dict()
audit['origin_counts'] = df['origin'].value_counts().to_dict()
audit['product_counts'] = df['product'].value_counts().to_dict()
audit['phase_counts'] = df['phase'].value_counts().to_dict()
audit['has_results'] = int(df['has_results'].sum())
audit['dose_reported'] = int(df['dose_reported'].sum())
io.open(os.path.join(OUT, 'registry_audit_v2.json'), 'w', encoding='utf-8').write(
    json.dumps(audit, indent=1, ensure_ascii=False))
print('included:', len(df), '| excluded non-msk:', audit['excluded_non_msk'])
print(json.dumps(audit, indent=1, ensure_ascii=False)[:1800])
