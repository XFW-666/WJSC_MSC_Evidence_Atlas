# -*- coding: utf-8 -*-
"""Fig 9: integration quadrant schematic with measured quantities."""
import io, os, json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from figstyle import plt, PALETTE

BASE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.join(BASE, 'results', 'registry')
SCR = os.path.join(BASE, 'results', 'scrna')
FIG = os.path.join(BASE, 'figures')
os.makedirs(FIG, exist_ok=True)

A = json.loads(io.open(os.path.join(REG, 'registry_analysis.json'), encoding='utf-8').read())
LOGJ = json.loads(io.open(os.path.join(BASE, 'results', 'bulk_analysis_log.json'), encoding='utf-8').read())
metrics = json.loads(io.open(os.path.join(SCR, 'scrna_metrics.json'), encoding='utf-8').read())
da = pd.read_csv(os.path.join(SCR, 'diff_abundance.csv'))
moddon = pd.read_csv(os.path.join(SCR, 'module_donor_stats.csv'))
mac = da[da['cell_type'] == 'macrophage/monocyte'].iloc[0]
fib = da[da['cell_type'] == 'fibroblast/MSC-lineage'].iloc[0]

fig, ax = plt.subplots(figsize=(12, 9))
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)
ax.axis('off')


def box(x, y, w, h, fc, ec='none', lw=1.2, r=1.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.6,rounding_size=%.1f' % r,
                                facecolor=fc, edgecolor=ec, linewidth=lw))


def txt(x, y, s, size=9.0, color='#222222', weight='normal', ha='center', va='center', ls=1.35):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va, linespacing=ls)


txt(50, 96.5, 'Trial-design premises confronted with measured public biology', size=12, weight='bold')

Q = [
    # (x, y, band color, premise title, premise lines, evidence lines)
    (2, 50, '#eaf1f8', 'PREMISE 1 — Dosing',
     'Registry: %d of %d trials (%.1f%%) state a numeric cell dose;\nstated doses span %d-fold (%.1f×10⁶ – %.0f×10⁶ cells);\nmedian planned enrolment %.0f participants' % (
         A['n_dose_numeric'], A['n_trials'], 100 * A['dose_share_of_with_n'], round(A['dose_fold_range']),
         A['dose_min'] / 1e6, A['dose_max'] / 1e6, A['enrollment']['median']),
     'GSE239343: ASC secretome reverses the TNF\nchondrocyte signature (%.0f%% of induced genes\nreturn ≥50%%; Spearman r = %.2f) — a real,\ndose-dependent pharmacology is plausible' % (
         100 * LOGJ['GSE239343']['rescue_up_ge50pct'], LOGJ['GSE239343']['rescue_vector_spearman_r']),
     'Consequence: dose finding is missing,\nnot impossible — adopt escalation designs'),
    (52, 50, '#fdeeee', 'PREMISE 2 — Donor state',
     'Registry: %d trials (%.1f%%) rely on autologous\nharvest; 56.8%% of trials leave cell origin unspecified' % (
         A['origin_counts'].get('autologous', 0), 100.0 * A['origin_counts'].get('autologous', 0) / A['n_trials']),
     'GSE267908: OA-donor vs non-OA-donor MSCs —\nno BH-significant gene at 3v3; senescence module\nnominally LOWER in OA donors (P = 0.057)',
     'Consequence: no intrinsic transcriptomic\nbarrier to autologous sourcing; product\ncharacterisation must fill the gap'),
    (2, 4, '#edf3ea', 'PREMISE 3 — A homogeneous target joint',
     'Registry: single-arm designs dominate;\nno inflammatory or pain stratification in the\nstructured eligibility fields of the programme',
     'GSE248453 single-cell atlas: fibroblast/MSC-lineage\nshare %.1f%% (high pain) vs %.1f%% (low pain) and\nmacrophage share %.1f%% vs %.1f%% (both P = %.3f);\nSASP activity higher in low-pain fibroblasts (P = %.3f)' % (
         fib['mean_high'], fib['mean_low'], mac['mean_high'], mac['mean_low'], mac['MWU_p'],
         moddon[(moddon['cell_type'] == 'fibroblast/MSC-lineage') & (moddon['module'] == 'sasp')].iloc[0]['MWU_p']),
     'Consequence: stratify enrolment by\nsynovitis/pain phenotype'),
    (52, 4, '#fffbe8', 'PREMISE 4 — The evidence accumulates',
     'Registry: only %d of %d trials (%.1f%%) have posted\nresults; %.1f%% of trials have unknown status;\nmedian posting lag %.1f years' % (
         A['n_results'], A['n_trials'], 100 * A['share_results'],
         100.0 * A['status_groups']['unknown status'] / A['n_trials'],
         A['results_post_lag_median_y']),
     'Cross-check: completed-with-results trials in this\natlas are the exception, so published meta-analyses\nsample an unquantifiable subset of attempts\n[Zarin 2019; Nelson 2023]',
     'Consequence: mandatory results reporting is\nthe cheapest upgrade available'),
]
for x, y, fc, title, prem, ev, cons in Q:
    box(x, y, 46, 42, fc)
    txt(x + 23, y + 38.5, title, size=10.2, weight='bold', color='#333333')
    txt(x + 23, y + 31.5, prem, size=8.6)
    txt(x + 23, y + 20.5, ev, size=8.6, color='#333333')
    txt(x + 23, y + 8.2, cons, size=9.0, weight='bold', color=PALETTE['main'])
    ax.annotate('', xy=(x + 3.5, y + 12), xytext=(x + 3.5, y + 36),
                arrowprops=dict(arrowstyle='-|>', color='#888888', lw=1.6))

fig.savefig(os.path.join(FIG, 'Fig9_integration_mpl.png'), dpi=920)
fig.savefig(os.path.join(FIG, 'Fig9_integration.pdf'), dpi=920)
plt.close(fig)
print('Fig9 saved')
